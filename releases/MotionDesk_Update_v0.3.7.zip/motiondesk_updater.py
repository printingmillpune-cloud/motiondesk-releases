"""MotionDesk owner-controlled update client.

Remote updates are disabled until a trusted release feed exists. ZIPs are
limited to MotionDesk code files, never to owner project/data directories.
"""
from __future__ import annotations
import hashlib
import io
import json
import os
import re
import shutil
import threading
import time
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlsplit
import zipfile
import requests

APP_VERSION = '0.3.7'
ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('MOTIONDESK_DATA_DIR',os.environ.get('SPEEDYPRO_DATA_DIR',str(ROOT/'data')))).resolve()
DATA.mkdir(parents=True,exist_ok=True)
STATE_PATH = DATA/'update_state.json'
RELEASE_FEED = os.getenv('MOTIONDESK_RELEASE_FEED','https://raw.githubusercontent.com/printingmillpune-cloud/motiondesk-releases/main/latest.json').strip()
TRUSTED_REPOSITORY = 'printingmillpune-cloud/motiondesk-releases'
MAX_ZIP = 10 * 1024 * 1024
ALLOWED_FILES = {
    'app.py','motiondesk_updater.py','motiondesk_apply_update.py',
    'launch_motiondesk.py', 'static/app.js','static/index.html','static/style.css',
}
LOCK = threading.Lock()


def save_state(**values):
    with LOCK:
        old = {}
        if STATE_PATH.exists():
            try: old=json.loads(STATE_PATH.read_text(encoding='utf-8'))
            except Exception: pass
        old.update(values)
        old['updated_at']=time.time()
        temp=STATE_PATH.with_suffix('.tmp')
        temp.write_text(json.dumps(old,indent=2),encoding='utf-8')
        temp.replace(STATE_PATH)
        return old


def state():
    try:return json.loads(STATE_PATH.read_text(encoding='utf-8'))
    except Exception:return {'status':'idle','progress':0}


def version_tuple(version):
    if not re.fullmatch(r'\d+\.\d+\.\d+',str(version)):raise ValueError('Invalid release version')
    return tuple(int(x) for x in version.split('.'))


def trusted_url(url: str, *, feed=False) -> bool:
    if not url: return False
    parts=urlsplit(url)
    if parts.username or parts.password or parts.fragment or parts.query:return False
    if parts.scheme=='https' and parts.hostname in {'raw.githubusercontent.com','github.com'}:
        prefix = '/'+TRUSTED_REPOSITORY+'/'
        # raw.githubusercontent: /owner/repo/main/latest.json
        # github.com: /owner/repo/releases/download/... ; no arbitrary redirects allowed
        if parts.hostname=='raw.githubusercontent.com':
            return parts.path.startswith(prefix) and (not feed or parts.path.endswith('/latest.json'))
        return parts.path.startswith(prefix+'releases/download/') and not feed
    if os.getenv('MOTIONDESK_ALLOW_TEST_UPDATES')=='1' and parts.scheme=='http' and parts.hostname in {'127.0.0.1','localhost'}:
        return True
    return False


def request_bytes(url, max_length, timeout):
    if not trusted_url(url): raise ValueError('Update address is not an approved MotionDesk release URL')
    resp=requests.get(url,timeout=timeout,stream=True,allow_redirects=False)
    resp.raise_for_status()
    if resp.is_redirect: raise ValueError('Update redirects are not allowed')
    buf=bytearray()
    for chunk in resp.iter_content(chunk_size=65536):
        buf.extend(chunk)
        if len(buf)>max_length: raise ValueError('Update exceeds download size limit')
    return bytes(buf)


def get_manifest():
    if not RELEASE_FEED: return None
    if not trusted_url(RELEASE_FEED,feed=True): raise ValueError('Configured release source is not trusted')
    obj=json.loads(request_bytes(RELEASE_FEED,65536,12).decode('utf-8'))
    if obj.get('app')!='MotionDesk' or int(obj.get('schema',0))!=1:raise ValueError('Invalid MotionDesk release manifest')
    version_tuple(obj.get('version',''))
    url=obj.get('download_url','')
    if not trusted_url(url):raise ValueError('Release package is not from the trusted repository')
    if not re.fullmatch(r'[0-9a-f]{64}',obj.get('sha256','')):raise ValueError('Missing release SHA-256 checksum')
    return obj


def check():
    if not RELEASE_FEED:
        return {'configured':False,'available':False,'current':APP_VERSION,'status':'release_channel_missing',
            'message':'The update button is installed. Connect the dedicated MotionDesk release repository once to receive future updates.'}
    try:
        m=get_manifest()
        available=version_tuple(m['version'])>version_tuple(APP_VERSION)
        return {'configured':True,'available':available,'current':APP_VERSION,'latest':m['version'],
                'notes':str(m.get('notes',''))[:600],
                'message':('Version '+m['version']+' is ready to install.' if available else 'MotionDesk is up to date.')}
    except requests.HTTPError as exc:
        if getattr(exc.response,'status_code',None)==404:
            return {'configured':False,'available':False,'current':APP_VERSION,'status':'release_not_published',
                'message':'Updater is ready. The dedicated MotionDesk release repository still needs its first published release.'}
        return {'configured':True,'available':False,'current':APP_VERSION,'status':'check_failed',
                'message':'Update server not available: '+str(exc)[:180]}
    except Exception as exc:
        return {'configured':True,'available':False,'current':APP_VERSION,'status':'check_failed',
                'message':'Unable to verify the release channel: '+str(exc)[:180]}


def validate_archive(contents:bytes):
    tmp=io.BytesIO(contents)
    try:zf=zipfile.ZipFile(tmp)
    except zipfile.BadZipFile as exc:raise ValueError('Invalid update ZIP') from exc
    files=[]
    for entry in zf.infolist():
        name=entry.filename.replace('\\','/')
        if entry.is_dir(): continue
        if name not in ALLOWED_FILES:raise ValueError('Unapproved update file: '+name)
        if entry.file_size>5*1024*1024:raise ValueError('Unexpected large source file')
        if entry.external_attr >> 16 & 0o170000 == 0o120000:raise ValueError('Symbolic links are not allowed')
        files.append(name)
    if not files or 'app.py' not in files:raise ValueError('Update is missing the main application file')
    if len(files)!=len(set(files)):raise ValueError('Update ZIP has duplicate filenames')
    return zf,files


def stage_update():
    m=get_manifest()
    if version_tuple(m['version'])<=version_tuple(APP_VERSION):raise ValueError('No newer release available')
    save_state(status='downloading',progress=10,message='Downloading verified update…',target_version=m['version'])
    raw=request_bytes(m['download_url'],MAX_ZIP,120)
    actual=hashlib.sha256(raw).hexdigest()
    if actual!=m['sha256']:raise ValueError('Update checksum did not match published release')
    save_state(status='verifying',progress=55,message='Verifying release contents…')
    zf, files=validate_archive(raw)
    root=DATA/'.staged_updates'/m['version']
    if root.exists():shutil.rmtree(root)
    root.mkdir(parents=True,exist_ok=True)
    with zf:
        for name in files:
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(zf.read(name))
    for name in files:
        if name.endswith('.py'):compile((root/name).read_text(encoding='utf-8'),name,'exec')
    save_state(status='staged',progress=70,message='Update verified. Restarting MotionDesk…')
    return root,m['version'],files


def launch_apply(root:Path,version:str,files:list[str],parent_pid:int):
    if not (ROOT/'motiondesk_apply_update.py').exists():raise ValueError('Update helper missing; re-run initial updater setup')
    cmd=[sys.executable,str(ROOT/'motiondesk_apply_update.py'),'--stage',str(root),
         '--version',version,'--pid',str(parent_pid),'--files',json.dumps(files)]
    kw={'cwd':str(ROOT),'stdin':subprocess.DEVNULL,'stdout':subprocess.DEVNULL,'stderr':subprocess.DEVNULL}
    if os.name=='nt': kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)|getattr(subprocess,'DETACHED_PROCESS',0)|getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
    else: kw['start_new_session']=True
    subprocess.Popen(cmd,**kw)
    save_state(status='restarting',progress=76,message='Applying update and restarting. Keep MotionDesk open…')


def install_async(parent_pid):
    s=state()
    if s.get('status') in {'downloading','verifying','staged','restarting'} and time.time()-s.get('updated_at',0)<600:
        raise ValueError('An update is already in progress')
    save_state(status='starting',progress=1,message='Checking release…')
    def job():
        try:
            path,version,files=stage_update()
            launch_apply(path,version,files,parent_pid)
        except Exception as exc:
            save_state(status='failed',progress=0,message='Update could not be applied: '+str(exc)[:400])
    threading.Thread(target=job,daemon=True).start()
    return state()
