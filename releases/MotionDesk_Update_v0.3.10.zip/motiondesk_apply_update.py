"""Detached update helper: backs up, applies and health-verifies source-code releases.
Never deletes owner projects, recordings, settings or environments.
"""
from __future__ import annotations
import argparse
import base64
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
import urllib.error

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('MOTIONDESK_DATA_DIR',os.environ.get('SPEEDYPRO_DATA_DIR',str(ROOT/'data')))).resolve()
STATE=DATA/'update_state.json'


def status(**kwargs):
    d={}
    try:d=json.loads(STATE.read_text(encoding='utf-8'))
    except Exception:pass
    d.update(kwargs)
    tmp=STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(d,indent=2),encoding='utf-8')
    tmp.replace(STATE)


def ping(version):
    try:
        password=os.environ.get('MOTIONDESK_APP_PASSWORD',os.environ.get('SPEEDYPRO_APP_PASSWORD',''))
        headers={}
        if password:
            headers['Authorization']='Basic '+base64.b64encode(('studio:'+password).encode()).decode()
        req=urllib.request.Request('http://127.0.0.1:8765/api/health',headers=headers)
        with urllib.request.urlopen(req,timeout=2) as r:
            v=json.load(r).get('version')
            return v==version
    except Exception:return False


def start_server():
    py=sys.executable
    log=DATA/'update_server.log'
    f=log.open('w',encoding='utf-8')
    kw={'cwd':str(ROOT),'stdout':f,'stderr':subprocess.STDOUT,'stdin':subprocess.DEVNULL}
    if os.name=='nt':kw['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)|getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)
    else:kw['start_new_session']=True
    p=subprocess.Popen([py,'-m','uvicorn','app:app','--host','127.0.0.1','--port','8765'],**kw)
    f.close()
    return p


def run():
    args=argparse.ArgumentParser()
    args.add_argument('--stage',required=True)
    args.add_argument('--version',required=True)
    args.add_argument('--pid',required=True,type=int)
    args.add_argument('--files',required=True)
    a=args.parse_args()
    stage=Path(a.stage).resolve()
    if not stage.is_relative_to(DATA):raise RuntimeError('Staging path must be inside MotionDesk data')
    allowed={'app.py','motiondesk_updater.py','motiondesk_apply_update.py','launch_motiondesk.py','static/app.js','static/index.html','static/style.css'}
    files=json.loads(a.files)
    if not files or set(files)-allowed:raise RuntimeError('Invalid update files')
    backup=DATA/'update_backups'/('pre_'+a.version+'_'+time.strftime('%Y%m%d_%H%M%S'))
    for filename in files:
        if not (stage/filename).is_file():raise RuntimeError('Staged source missing: '+filename)
    # Do not stop MotionDesk until all staged paths are verified.
    time.sleep(1)
    try:os.kill(a.pid,signal.SIGTERM)
    except OSError:pass
    time.sleep(1.5)
    backup.mkdir(parents=True,exist_ok=True)
    replaced=[]
    try:
        for filename in files:
            src=ROOT/filename;target=backup/filename
            target.parent.mkdir(parents=True,exist_ok=True)
            if src.exists():shutil.copy2(src,target)
        for filename in files:
            target=ROOT/filename
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(stage/filename,target)
            replaced.append(filename)
        status(status='restarting',progress=88,message='Update copied. Checking MotionDesk startup…')
        proc=start_server()
        for _ in range(45):
            if ping(a.version):
                status(status='completed',progress=100,message='MotionDesk updated to '+a.version+'. Your projects are preserved.')
                return
            if proc.poll() is not None:break
            time.sleep(.5)
        try:proc.terminate()
        except Exception:pass
        raise RuntimeError('New version did not pass startup health check')
    except Exception as exc:
        for filename in replaced:
            old=backup/filename
            target=ROOT/filename
            try:
                if old.exists():shutil.copy2(old,target)
                else:target.unlink(missing_ok=True)
            except OSError:pass
        start_server()
        status(status='rolled_back',progress=0,message='Update rolled back; previous version restored. '+str(exc)[:180])

if __name__=='__main__':
    try:run()
    except Exception as e:status(status='failed',progress=0,message='Update failed before installation: '+str(e)[:230])
