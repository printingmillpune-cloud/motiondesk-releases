const $=id=>document.getElementById(id);
const features=['Excel Import','Front Upload','Back Upload','Sleeve Upload','Front Number','Back Name','Back Number','Name Font','Number Font','Colour Gradient','Outline / Border','Name Curve','Sleeve Export','Print Files'];
const ROLES={raw_excel:'Excel / Player List',raw_front:'Original Front',raw_back:'Original Back',raw_sleeve:'Original Sleeve',final_front:'Final Front',final_back:'Final Back',final_sleeve:'Final Sleeve'};
let current=null,assignRole=null,selected={},featureSet=new Set(),frames=[],outputSuggestions=[],poll=null,guided=false;
let projectVoiceReady=false, projectMusicReady=false;
const audioBase=()=>current?'/api/project/'+current:'/api/audio-workspace';
function updateAudioScope(name){$('audioScope').textContent=name?'Audio target: '+name+' (current project)':'Audio target: Local Audio Workspace — upload a video later to apply it.';}

const REQUIRED_REVIEW=['raw_excel','raw_front','raw_back','final_front','final_back'];
function notice(t){const n=$('toast');n.textContent=t;n.hidden=false;setTimeout(()=>n.hidden=true,5200)}
async function request(url,opts={}){const r=await fetch(url,opts);let j=await r.json().catch(()=>({detail:'Unexpected response'}));if(!r.ok)throw new Error(j.detail||JSON.stringify(j));return j}
function tab(t){document.querySelectorAll('.tab').forEach(e=>e.classList.toggle('active',e.dataset.tab===t));document.querySelectorAll('.view').forEach(e=>e.hidden=e.id!==t);if(t==='library')refreshLibrary();if(t==='settings')refreshSettings()}
document.querySelectorAll('.tab').forEach(e=>e.onclick=()=>tab(e.dataset.tab));
$('videoFile').onchange=e=>$('videoPicked').textContent=e.target.files?.[0]?.name||'';
// Actual transfer progress (XHR), then separate local frame-scan progress.
function makeUpload(fd, onProgress){
 return new Promise((resolve,reject)=>{
  const xhr=new XMLHttpRequest();xhr.open('POST','/api/upload');
  xhr.upload.onprogress=e=>{if(e.lengthComputable)onProgress(Math.min(100,Math.round(e.loaded/e.total*100)))};
  xhr.onerror=()=>reject(new Error('Local upload connection failed'));
  xhr.onload=()=>{let j;try{j=JSON.parse(xhr.responseText)}catch{j={detail:'Invalid response'}}
    if(xhr.status>=200&&xhr.status<300)resolve(j);else reject(new Error(j.detail||'Upload failed'));
  };xhr.send(fd);
 });
}
function setStage(stage){
 const stages=['upload','scan','review','render','preview','download'];
 const idx=stages.indexOf(stage);
 document.querySelectorAll('.stage').forEach((e,i)=>{e.classList.toggle('active',i===idx);e.classList.toggle('done',i<idx)});
}
function setImportStatus(percent,label,active=true){
 $('importProgress').hidden=!active;
 $('importProgressFill').style.width=`${Math.max(0,Math.min(100,percent))}%`;
 $('importProgressLabel').textContent=label;
 $('importProgressFill').classList.toggle('active',active);
}
async function awaitScan(pid){
 for(let n=0;n<1200;n++){
  let job=await request('/api/project/'+pid+'/import-status');
  setImportStatus(job.progress||0,job.message,true);
  if(job.status==='completed')return job;
  if(job.status==='failed')throw new Error(job.message);
  await new Promise(r=>setTimeout(r,650));
 }
 throw new Error('Scan status timed out; check server log');
}
$('uploadForm').onsubmit=async(e)=>{
 e.preventDefault();let file=$('videoFile').files[0];if(!file){notice('Choose a video first');return}
 const fd=new FormData();fd.append('video',file);fd.append('name',$('episodeName').value);
 const initialAudio={music_url:$('project_music_file').files[0]?'':$('project_audio_url').value.trim(), rights:$('project_audio_rights').checked, music_volume:$('project_music_volume').value, music_speed:$('project_music_speed').value, voice_volume:$('project_voice_volume').value, lower:$('project_lower_music').checked};
 if(!validateMusicLink(initialAudio.music_url)){return;}
 if($('project_voice_file').files[0])fd.append('voice',$('project_voice_file').files[0]);
 if($('project_music_file').files[0])fd.append('music',$('project_music_file').files[0]);
 $('uploadBtn').disabled=true;setStage('upload');$('uploadMsg').textContent='Uploading locally…';
 setImportStatus(0,'Uploading 0%…',true);
 try{
   const p=await makeUpload(fd,x=>setImportStatus(x,`Uploading video: ${x}%`,true));
   setStage('scan');setImportStatus(0,'Upload complete. Scanning frames…',true);
   $('uploadMsg').textContent='Upload finished. Analyzing real footage…';
   await awaitScan(p.id);await openProject(p.id);
   $('project_audio_url').value=initialAudio.music_url;$('project_audio_rights').checked=initialAudio.rights;
   $('project_music_volume').value=initialAudio.music_volume;$('project_music_speed').value=initialAudio.music_speed;$('project_voice_volume').value=initialAudio.voice_volume;
   $('project_lower_music').checked=initialAudio.lower;updateAudioNumbers();
   if(initialAudio.music_url || initialAudio.music_volume!=='0.09' || initialAudio.voice_volume!=='1.15' || !initialAudio.lower){
     const ok=await saveProjectAudio(true);if(!ok)notice('Video imported; review music link before rendering.');}

   setStage('review');setImportStatus(100,'✓ Frame scan complete. Review required before video creation.',true);$('importProgressFill').classList.remove('active');
   $('uploadMsg').textContent='✓ Recording analyzed. Select at least one RAW DATA and one FINAL OUTPUT frame, then create both videos.';
   $('reviewNext').hidden=false;
   $('projectPanel').scrollIntoView({behavior:'smooth',block:'start'});
   startGuidedReview();
   notice('Frame scan ready. Choose the real Excel, original designs and final files.');
 }catch(err){$('uploadMsg').textContent='⚠ '+err.message;setImportStatus(0,'Unable to finish: '+err.message,false)}
 finally{$('uploadBtn').disabled=false}
};
$('reviewNext').onclick=startGuidedReview;
$('startReview').onclick=startGuidedReview;
let latestUpdate=null,updatePoll=null;
$('updateClose').onclick=()=>{$('updaterPanel').hidden=true;};
$('updateCheck').onclick=async()=>{
 $('updaterFill').style.width='0%';
 $('updateCheck').disabled=true;
 $('updaterPanel').hidden=false;$('updaterMessage').textContent='Checking MotionDesk updates…';
 try{
  const j=await request('/api/updates/check',{cache:'no-store'});
  $('updateStatus').textContent=j.message;
  $('updaterMessage').textContent=j.message;
  $('updaterDetails').textContent=j.latest?('Installed '+j.current+' · Latest '+j.latest):('Installed '+j.current);
  latestUpdate=j.available?j:null;
  $('installUpdate').hidden=!j.available;
  if(!j.available && j.status==='release_not_published'){
    $('updaterPanel').hidden=true;
    $('updateStatus').textContent='Online updates not configured';
  }else{
    $('updaterPanel').hidden=false;
    if(j.available)notice('MotionDesk '+j.latest+' available.');
  }
 }catch(e){$('updaterMessage').textContent='Could not check updates: '+e.message}
 finally{$('updateCheck').disabled=false}
};
$('installUpdate').onclick=async()=>{
 if(!latestUpdate)return;
 $('installUpdate').disabled=true;
 $('updaterPanel').hidden=false;
 $('updaterMessage').textContent='Verifying update package…';
 try{
  await request('/api/updates/install',{method:'POST'});
  const watch=async()=>{
   try{
    const x=await request('/api/updates/status',{cache:'no-store'});
    $('updaterFill').style.width=Math.min(100,x.progress||0)+'%';
    $('updaterMessage').textContent=x.message||x.status;
    $('updaterDetails').textContent='Stage: '+x.status;
    if(['completed','rolled_back','failed'].includes(x.status)){
      clearInterval(updatePoll); updatePoll=null; $('installUpdate').disabled=false;
      if(x.status==='completed')setTimeout(()=>location.reload(),1200);
    }
   }catch(e){
     // Server may briefly be down while the verified update restarts it.
     $('updaterDetails').textContent='Restarting local service…';
   }
  };
  await watch();updatePoll=setInterval(watch,1200);
 }catch(e){$('updaterMessage').textContent='Update was not started: '+e.message;$('installUpdate').disabled=false}
};
async function openProject(id){
 current=id;const p=await request('/api/project/'+id);updateAudioScope(p.name||id);frames=p.frames;selected={...p.selected};outputSuggestions=p.output_suggestions||[];featureSet=new Set(p.features||[]);
 $('projectPanel').hidden=false;$('evidence').textContent='Source analysis: '+p.evidence+'. No original/front/back roles are guessed by timestamp.';
 displayRoles();displayOutputSuggestions();displayFeatures();setProjectAudio(p);renderDownloads(p.outputs,!!p.download_approved);refreshReviewStatus();if(Object.keys(p.outputs||{}).length)setStage(p.download_approved?'download':'preview');
 const vid=$('sourcePreview');if(vid){vid.src='/api/project/'+current+'/source';vid.load()}
}
function pickTime(idx){return frames.find(f=>f.id===idx)}
function nextReviewRole(){return REQUIRED_REVIEW.find(role=>selected[role]===undefined||selected[role]===null)||REQUIRED_REVIEW[0]}
function hasRawAndFinal(){return ['raw_excel','raw_front','raw_back','raw_sleeve'].some(k=>selected[k]!==null&&selected[k]!==undefined) && ['final_front','final_back','final_sleeve'].some(k=>selected[k]!==null&&selected[k]!==undefined)}
function refreshReviewStatus(){
 const n=REQUIRED_REVIEW.filter(role=>selected[role]!==null&&selected[role]!==undefined).length;
 const ready=hasRawAndFinal();
 $('guidedReviewStatus').querySelector('span').textContent=`${n}/5 main views selected. ${ready?'Ready to create videos. Add the remaining views if they appear in the recording.':'Select at least one RAW DATA and one SPEEDYPRO WORK view.'} Sleeve views are optional.`;
 $('renderBtn').disabled=!ready;
 $('renderStatus').textContent=ready?'✓ Frames ready. Click Create Both Videos.':'Choose one original/raw view and one actual final output, then export.';
}
function startGuidedReview(){
 if(!current){notice('Upload a recording first');return}
 guided=true;showPicker(nextReviewRole());
}
async function persistReview(){
 if(!current)return;
 try{await request('/api/project/'+current+'/selection',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({selected,features:[...featureSet],evidence:'owner-reviewed'})});return true}
 catch(e){notice('Could not save selection: '+e.message);return false}
}
function reviewAdvance(){
 if(!guided){$('framepicker').hidden=true;return}
 const idx=REQUIRED_REVIEW.indexOf(assignRole);
 if(idx>=0 && idx<REQUIRED_REVIEW.length-1){showPicker(REQUIRED_REVIEW[idx+1]);return}
 guided=false;$('framepicker').hidden=true;refreshReviewStatus();
 if(hasRawAndFinal()){$('renderBtn').scrollIntoView({behavior:'smooth',block:'center'});notice('Review saved. Video export is ready.')}else{notice('Select at least one RAW DATA and one FINAL OUTPUT frame before rendering.')}
}
function displayRoles(){
 for(const key of ['raw','final']){$(key+'Roles').innerHTML=Object.keys(ROLES).filter(x=>x.startsWith(key+'_')).map(role=>{
 const f=pickTime(selected[role]);const proposal=role==='final_front'?outputSuggestions[0]:role==='final_back'?outputSuggestions[1]:null;
 return `<div class="roleCard" role="button" tabindex="0" title="Choose real frame" data-role="${role}"><b>${ROLES[role]}</b>${f?`<img src="${f.url}" alt="Verified view of ${ROLES[role]}"><small>${f.time}s · confirmed</small>`:proposal?`<img class="suggestedImage" src="${proposal.url}" alt="Unverified possible export screenshot"><small class="suggestedText">Possible output · ${proposal.time}s · click to verify</small>`:`<div class="hint unverified">Needs verification · click to choose</div><small>Find frame in recording</small>`}</div>`
 }).join('')}
 document.querySelectorAll('.roleCard').forEach(c=>{c.onclick=()=>{guided=false;showPicker(c.dataset.role)};c.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();guided=false;showPicker(c.dataset.role)}}})
 refreshReviewStatus()
}
function displayOutputSuggestions(){
 // Keep the useful candidate images in Final Front/Back cards and frame picker.
 // Avoid duplicating a confusing strip of unverified images on the main page.
}
function displayFeatures(){
 $('features').innerHTML=features.map(f=>`<button class="chip ${featureSet.has(f)?'selected':''}" data-feature="${f}">${f}</button>`).join('');
 document.querySelectorAll('.chip').forEach(ch=>ch.onclick=()=>{featureSet.has(ch.dataset.feature)?featureSet.delete(ch.dataset.feature):featureSet.add(ch.dataset.feature);displayFeatures()})
}
function updateGallery(range='all'){
 const duration=Number($('sourcePreview').duration)||99999;
 const filtered=frames.filter(f=>range==='all'||(range==='start'&&f.time<20)||(range==='middle'&&f.time>=20&&f.time<duration-20)||(range==='end'&&f.time>=Math.max(20,duration-20))||(range==='output'&&f.time>=duration*.60));
 $('candidateGrid').innerHTML=`<button class="candidate" data-id="none">⊘ Not available in source</button>`+
 filtered.map(f=>`<button class="candidate" data-id="${f.id}"><img src="${f.url}" loading="lazy" alt="Frame at ${f.time} seconds"><span>${f.time}s</span></button>`).join('');
 document.querySelectorAll('.candidate').forEach(b=>b.onclick=async()=>{
   const role=assignRole;
   selected[role]=b.dataset.id==='none'?null:Number(b.dataset.id);
   displayRoles();const saved=await persistReview();
   if(!saved)return;
   notice(`${ROLES[role]} ${selected[role]===null?'skipped':'saved'}.`);
   reviewAdvance();
 });
}
function showPicker(role){
 assignRole=role;$('pickerHeading').textContent='Choose actual footage for '+ROLES[role];$('pickerStep').textContent=`${guided?'Guided review':'Manual selection'} · ${REQUIRED_REVIEW.includes(role)?(REQUIRED_REVIEW.indexOf(role)+1)+'/5':'Optional'} · ${ROLES[role]} — choose the real frame shown in your recording.`;$('framepicker').hidden=false;
 const proposal=role==='final_front'?outputSuggestions[0]:role==='final_back'?outputSuggestions[1]:null;
 const range=(role.startsWith('final_')&&outputSuggestions.length)?'output':'all';
 $('pickerRange').value=range;updateGallery(range);
 const f=pickTime(selected[role])||proposal;if(f){$('seekTime').value=Number(f.time).toFixed(2);seekToTime(Number(f.time))}
 $('framepicker').scrollIntoView({behavior:'smooth',block:'start'});
}
function seekToTime(t){let v=$('sourcePreview');if(Number.isFinite(t)&&v.readyState>0){let dur=Number.isFinite(v.duration)?v.duration:999999;v.currentTime=Math.max(0,Math.min(t,dur-.05))}}
$('pickerRange').onchange=()=>updateGallery($('pickerRange').value);
$('pickerClose').onclick=()=>{guided=false;$('framepicker').hidden=true};
$('pickerSkip').onclick=async()=>{selected[assignRole]=null;displayRoles();if(await persistReview())reviewAdvance()};
$('pickerFinish').onclick=()=>{guided=false;$('framepicker').hidden=true;refreshReviewStatus();$('renderBtn').scrollIntoView({behavior:'smooth',block:'center'})};
$('seekTime').onchange=()=>seekToTime(Number($('seekTime').value));
$('sourcePreview').onseeked=()=>{$('seekTime').value=Number($('sourcePreview').currentTime).toFixed(2)};
$('sourcePreview').ontimeupdate=()=>{$('seekTime').value=Number($('sourcePreview').currentTime).toFixed(2)};
$('seekBack').onclick=()=>{let v=$('sourcePreview');seekToTime(Math.max(0,v.currentTime-.1))};
$('seekForward').onclick=()=>{let v=$('sourcePreview');seekToTime(v.currentTime+.1)};
$('captureExact').onclick=async()=>{
 if(!current||!assignRole)return;const t=Number($('sourcePreview').currentTime||$('seekTime').value);
 $('captureExact').disabled=true;$('captureState').textContent='Capturing frame directly from the original recording…';
 try{const j=await request('/api/project/'+current+'/capture-frame',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({role:assignRole,time:t})});
 frames.push(j.frame);selected={...j.selected};$('captureState').textContent=`Captured ${j.frame.time}s for ${ROLES[assignRole]}.`;
 displayRoles();notice('Exact source frame captured and saved.');reviewAdvance();
 }catch(e){$('captureState').textContent=e.message}finally{$('captureExact').disabled=false}
};
$('rescanBtn').onclick=async()=>{
 if(!current){notice('Upload a recording first');return}
 $('rescanBtn').disabled=true;$('rescanBtn').classList.add('working');$('evidence').textContent='Rescanning video… please keep the app open. You will see all candidates in the gallery.';
 try{
   const a=await request('/api/project/'+current+'/rescan',{method:'POST'});
   if(a.status!=='scanning')throw new Error('Scan did not start');
   for(let n=0;n<1200;n++){
     await new Promise(r=>setTimeout(r,800));
     const s=await request('/api/project/'+current+'/rescan-status');
     $('evidence').textContent=`Rescanning ${s.progress||0}% — ${s.message||'finding real frames'}`;
     if(s.status==='failed')throw new Error(s.message);
     if(s.status==='completed'){
       const p=await request('/api/project/'+current);frames=p.frames;selected={...p.selected};outputSuggestions=p.output_suggestions||[];displayRoles();displayOutputSuggestions();
       $('evidence').textContent=`Rescan complete — ${frames.length} real frame candidates. Gallery opened. Choose the correct view below.`;
       $('pickerRange').value='all';startGuidedReview();notice(`Rescan complete — ${frames.length} frames available to choose`);return;
     }
   }
   throw new Error('Rescan timed out. Open Library and try again.');
 }catch(e){$('evidence').textContent='Rescan failed: '+e.message;notice('Rescan error: '+e.message)}
 finally{$('rescanBtn').disabled=false;$('rescanBtn').classList.remove('working')}
};
$('saveSelection').onclick=async()=>{
 try{if(await persistReview()){refreshReviewStatus();notice('Frame selections & feature badges saved.')}}
 catch(e){notice(e.message)}
};
$('aiBtn').onclick=async()=>{
 if(!confirm('This uses a separately billed OpenAI API, only if configured. Review costs before confirming. Scan selected screenshots?'))return;
 try{const a=await request('/api/project/'+current+'/ai-analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({acknowledge_billed_api:true})});
 selected=a.selected;featureSet=new Set(a.features);displayRoles();displayFeatures();$('evidence').textContent='AI suggestions (not verified): '+a.notes;notice('AI suggestions loaded; review before export')}
 catch(e){notice('AI not run: '+e.message)}
};
function setProjectAudio(p){
 const x=p.audio||{};
 projectVoiceReady=!!p.voice_file;projectMusicReady=!!(p.music_file||p.linked_music_file);
 $('project_audio_url').value=x.music_url||'';
 $('project_audio_rights').checked=!!x.music_url;
 $('project_music_volume').value=x.music_volume??0.09;
 $('project_music_speed').value=x.music_speed??1.0;
 $('project_voice_volume').value=x.voice_volume??1.15;
 $('project_lower_music').checked=x.lower_music_voiceover!==false;
 $('project_music_file').value='';$('project_voice_file').value='';
 updateAudioNumbers();updateLinkHelp();
 $('audioStatus').textContent=(p.linked_music_file?'Music link imported. ':p.music_file?'Music file uploaded. ':'Built-in music selected. ')+(p.voice_file?'Voiceover loaded.':'');
}
function updateAudioNumbers(){
 $('projectMusicValue').textContent=Math.round(Number($('project_music_volume').value)*100)+'%';
 $('projectVoiceValue').textContent=Math.round(Number($('project_voice_volume').value)*100)+'%';
 $('projectSpeedValue').textContent=Number($('project_music_speed').value).toFixed(2)+'×';
}
function socialMusicUrl(url){try{const h=new URL(url).hostname.toLowerCase();return ['instagram.com','youtube.com','youtu.be','facebook.com','tiktok.com'].some(s=>h===s||h.endsWith('.'+s))}catch{return false}}
function validateMusicLink(url){
 if(!url)return true;
 if(socialMusicUrl(url)){
  const h=new URL(url).hostname.toLowerCase();
  if(!(h.endsWith('instagram.com')||h.endsWith('facebook.com')||h==='fb.watch'||h==='www.fb.watch')){
   notice('Only public Instagram/Facebook Reels are supported; YouTube music is not imported.');return false;
  }
 }
 return true;
}
function updateLinkHelp(){
 const url=$('project_audio_url').value.trim(),el=$('musicLinkHelp');
 const social=socialMusicUrl(url);el.classList.toggle('warning',false);
 el.textContent=social?'Public Reel link detected. Save Audio will try a free local extraction (no login/cookies). Availability varies. You need permission to reuse the soundtrack.':
  'Paste a public accessible Instagram/Facebook Reel URL or authorized direct HTTPS audio URL. No paid AI API.';
 $('applyAudio').textContent=social?'Get Reel MP3 & Save':'Save Audio Settings';
}
$('project_audio_url').addEventListener('input',()=>{if($('project_audio_url').value.trim())$('project_music_file').value='';updateLinkHelp()});
$('project_music_file').addEventListener('change',()=>{if($('project_music_file').files[0]){$('project_audio_url').value='';updateLinkHelp()}});
$('project_music_volume').oninput=updateAudioNumbers;
$('project_music_speed').oninput=updateAudioNumbers;
$('project_voice_volume').oninput=updateAudioNumbers;
async function saveProjectAudio(silent=false){
 const fd=new FormData();
 const url=$('project_audio_url').value.trim();
 if(!validateMusicLink(url))return false;
 const file=$('project_music_file').files[0],voice=$('project_voice_file').files[0];
 fd.append('music_url',file?'':url);
 fd.append('rights_confirmed',$('project_audio_rights').checked?'true':'false');
 fd.append('music_volume',$('project_music_volume').value);
 fd.append('music_speed',$('project_music_speed').value);
 fd.append('voice_volume',$('project_voice_volume').value);
 fd.append('lower_music_voiceover',$('project_lower_music').checked?'true':'false');
 if(file)fd.append('music',file);if(voice)fd.append('voice',voice);
 const btn=$('applyAudio');btn.disabled=true;
 $('audioStatus').textContent=socialMusicUrl(url)?'⟳ Trying public Reel audio and converting to MP3. This can take a moment…':'⟳ Saving audio and mixer settings…';
 try{
  const saveEndpoint=current?audioBase()+'/audio':audioBase();
  const r=await request(saveEndpoint,{method:'POST',body:fd});
  projectVoiceReady=!!r.audio.has_voice;projectMusicReady=!!r.audio.has_music;
  $('audioStatus').textContent='✓ Audio ready in '+(current?'current project':'local workspace')+'. '+
     (r.audio.has_voice?'Voiceover ready. ':'')+(r.audio.has_music?'Custom music ready.':'Built-in music ready.')+
     (current?' Re-render to apply changes.':' Saved for your next video upload.');
  if(!silent){if(current)renderDownloads({},false);notice('Audio saved. Now press Test Music to hear it.');}
  $('project_music_file').value='';$('project_voice_file').value='';return true;
 }catch(e){$('audioStatus').textContent='⚠ '+e.message;notice('Audio not saved: '+e.message);return false;}
 finally{btn.disabled=false;}
}
$('applyAudio').onclick=async()=>{const btn=$('applyAudio');btn.setAttribute('aria-busy','true');try{await saveProjectAudio(false)}finally{btn.removeAttribute('aria-busy')}};
let testBlobURL=null;
async function playAudio(kind){
 const player=$('audioTestPlayer'),msg=$('audioTestState');
 const key=kind==='music'?'testMusic':kind==='voice'?'testVoice':'testMix',btn=$(key);
 btn.disabled=true;
 msg.textContent='⟳ Preparing '+(kind==='mix'?'music + voice':kind)+' audio test…';
 try{
  if(kind==='mix' && !projectVoiceReady && !$('project_voice_file').files[0]){
     throw new Error('Choose a Voiceover file first to test Music + Voice Together.');
  }
  if(kind==='voice' && !projectVoiceReady && !$('project_voice_file').files[0]){
     throw new Error('Choose a Voiceover file first to test it.');
  }
  if(!(await saveProjectAudio(true))){msg.textContent='⚠ Save audio first (check the message above).';return}
  if(testBlobURL){URL.revokeObjectURL(testBlobURL);testBlobURL=null;}
  player.pause();player.removeAttribute('src');
  const response=await fetch(audioBase()+'/audio-test/'+kind+'?t='+Date.now(),{cache:'no-store'});
  if(!response.ok){let err=await response.json().catch(()=>({detail:response.statusText}));throw new Error(err.detail||'Preview request failed');}
  const blob=await response.blob();
  if(!blob.size)throw new Error('The preview audio is empty.');
  testBlobURL=URL.createObjectURL(blob);player.src=testBlobURL;
  player.load();await player.play();
  msg.textContent='▶ Playing '+(kind==='mix'?'music + voice mix':kind)+' at your selected volume/speed.';
 }catch(e){msg.textContent='⚠ '+(e.message||e);notice('Audio test: '+(e.message||e));}
 finally{btn.disabled=false;}
}
$('testMusic').onclick=()=>playAudio('music');
$('testVoice').onclick=()=>playAudio('voice');
$('testMix').onclick=()=>playAudio('mix');
async function removeAudio(kind){
 const btn=$(kind==='music'?'removeMusic':'removeVoice');btn.disabled=true;
 $('audioTestState').textContent='⟳ Removing '+kind+'…';
 $('audioTestPlayer').pause();$('audioTestPlayer').removeAttribute('src');
 if(testBlobURL){URL.revokeObjectURL(testBlobURL);testBlobURL=null;}
 if(kind==='music'){$('project_music_file').value='';$('project_audio_url').value='';$('project_audio_rights').checked=false;updateLinkHelp()}
 else $('project_voice_file').value='';
 try{
  const r=await request(audioBase()+'/audio-remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind})});
  if(kind==='music')projectMusicReady=false;else projectVoiceReady=false;
  $('audioTestState').textContent=kind==='music'?'✓ Custom music removed. Built-in music is now selected.':'✓ Voiceover removed.';
  $('audioStatus').textContent='✓ '+kind+' removed from '+(current?'project':'audio workspace')+'.';
  if(current)renderDownloads({},false);
 }catch(e){$('audioTestState').textContent='⚠ Could not remove audio: '+e.message;notice(e.message)}
 finally{btn.disabled=false;}
}
$('removeMusic').onclick=()=>removeAudio('music');
$('removeVoice').onclick=()=>removeAudio('voice');

$('renderBtn').onclick=()=>startRender(true);
function setRenderState(percent,message,active){
 $('renderProgressWrap').hidden=!active;
 $('renderProgressFill').style.width=Math.min(100,Math.max(0,percent||0))+'%';
 $('renderProgressText').textContent=percent?`${Math.round(percent)}% · ${message}`:message;
 $('renderProgressFill').classList.toggle('active',active);
}
async function startRender(reviewed){
 if(!current){notice('Upload a video first');return}
 try{
 if(reviewed){const ok=await persistReview();if(!ok)return}
 if(!(await saveProjectAudio(true)))return;
 const a=await request('/api/project/'+current+'/render',{method:'POST'});
 renderDownloads({},false);setStage('render');$('renderStatus').textContent=a.message;$('renderBtn').disabled=true;setRenderState(0,'Starting render...',true);
 if(poll)clearInterval(poll);
 poll=setInterval(async()=>{
   try{let j=await request('/api/project/'+current+'/status');$('renderStatus').textContent=j.message;
     setRenderState(j.progress||0,j.message,j.status==='running');
     if(j.status!=='running'){
       clearInterval(poll);$('renderBtn').disabled=false;
       if(j.status==='completed'){
         setRenderState(100,'Videos ready — downloads below',false);
         setStage('preview');const p=await request('/api/project/'+current);renderDownloads(p.outputs,false);$('previewStage').scrollIntoView({behavior:'smooth',block:'start'});notice('Four videos rendered. Watch and approve before downloading.')
       }else{
         $('renderStatus').textContent='Render failed: '+j.message;
         notice('Render stopped. Download unavailable until render finishes. See exact error below.');
       }
     }
   }catch(e){clearInterval(poll);$('renderBtn').disabled=false;setRenderState(0,'Could not check render status',false);notice(e.message)}
 },1300)
 }catch(e){notice(e.message);$('renderBtn').disabled=false}
}
function renderDownloads(out,approved=false){
 const entries=Object.entries(out||{});
 const preview=$('previewApproval');preview.hidden=!entries.length;$('previewEmpty').hidden=!!entries.length;
 $('outputs').innerHTML=entries.map(([k,v])=>`<div class="output"><strong>${k.includes('16x9')?'YouTube / Facebook':'Instagram Rotated'} · ${k.includes('teaser')?'Before/After Slowmo':'Detailed Workflow'}</strong><button type="button" class="secondary previewOne" data-key="${k}">▶ Preview Video</button><a class="downloadLink" href="${v.url}" download ${approved?'':'hidden'}>↓ Download Approved MP4</a><small>${v.duration}s · ${v.width}×${v.height}</small><div class="dlProgress" aria-live="polite"></div></div>`).join('')+
 (current&&entries.length?`<div class="output"><strong>Covers + Reports</strong><a class="downloadLink" href="/api/file/${current}/exports/Cover_16x9.png" download ${approved?'':'hidden'}>↓ Landscape Cover</a><a class="downloadLink" href="/api/file/${current}/exports/Cover_9x16.png" download ${approved?'':'hidden'}>↓ Instagram Cover</a><a class="downloadLink" href="/api/file/${current}/exports/Production_Report.json" download ${approved?'':'hidden'}>↓ QA Report</a><a class="downloadLink" href="/api/file/${current}/exports/Publishing_Copy.txt" download ${approved?'':'hidden'}>↓ Publishing Copy</a><div class="dlProgress" aria-live="polite"></div></div>`:'');
 const chooser=$('previewChoice');chooser.innerHTML=entries.map(([k,v])=>`<option value="${v.url.split('/').pop()}">${k.includes('16x9')?'16:9':'9:16'} · ${k.includes('teaser')?'Before/After':'Detailed'}</option>`).join('');
 const video=$('finishedPreview');if(entries.length){updatePreviewSource();}
 $('reviewConfirm').checked=!!approved;
 $('reviewConfirm').disabled=approved||!entries.length;
 $('approveVideos').disabled=approved||!entries.length;
 if(!approved)$('approveVideos').disabled=true;
 if(approved)setStage('download');
 $('previewState').textContent=approved?'✓ Approved. Downloads are unlocked.':'Play each video and tick the review checkbox to enable approval.';
 $('previewChoice').onchange=updatePreviewSource;
 document.querySelectorAll('.previewOne').forEach(b=>b.onclick=()=>{const rec=out[b.dataset.key];chooser.value=rec.url.split('/').pop();updatePreviewSource();preview.scrollIntoView({behavior:'smooth',block:'start'});});
 document.querySelectorAll('.downloadLink').forEach(a=>a.onclick=downloadWithProgress);
}
function updatePreviewSource(){
 if(!current)return;const name=$('previewChoice').value;
 const v=$('finishedPreview');v.pause();v.src='/api/project/'+current+'/preview/'+encodeURIComponent(name);v.load();
 $('previewPlayingName').textContent=$('previewChoice').selectedOptions[0]?.textContent||'Finished Video';
}
$('reviewConfirm').onchange=()=>{$('approveVideos').disabled=!$('reviewConfirm').checked;$('previewState').textContent=$('reviewConfirm').checked?'Ready to approve. This will unlock download links.':'Play the finished MP4 and tick this box when satisfied.';};
$('changeBeforeApprove').onclick=()=>{$('audioPanel').scrollIntoView({behavior:'smooth',block:'start'});notice('Adjust music, voice or frame selections, then click Create Both Videos to refresh the preview.');};
$('finishedPreview').onerror=()=>{$('previewState').textContent='⚠ Preview could not load this file. Check local render status before approval.';};
$('approveVideos').onclick=async()=>{
 if(!current||!$('reviewConfirm').checked){notice('Preview the finished video and tick the review confirmation first.');return;}$('approveVideos').disabled=true;$('previewState').textContent='⟳ Checking all output files…';
 try{await request('/api/project/'+current+'/approve',{method:'POST'});const p=await request('/api/project/'+current);renderDownloads(p.outputs,true);setStage('download');notice('✓ Videos approved. Download buttons are now available.');}
 catch(e){$('previewState').textContent='⚠ '+e.message; $('approveVideos').disabled=false;notice(e.message)}
};
async function downloadWithProgress(e){
 e.preventDefault();const a=e.currentTarget;const box=a.closest('.output');const progress=box.querySelector('.dlProgress');const url=a.href;
 a.classList.add('downloading');progress.textContent='⟳ Preparing download…';
 try{
 const response=await fetch(url);if(!response.ok)throw new Error('File not found / render did not complete');
 const bytes=Number(response.headers.get('content-length')||0);
 if(bytes>250*1024*1024){progress.textContent='⟳ Large file — browser download is starting';window.location.href=url;return}
 if(!response.body){window.location.href=url;progress.textContent='⟳ Browser download started';return}
 const reader=response.body.getReader();let total=0;const chunks=[];
 while(true){const {done,value}=await reader.read();if(done)break;chunks.push(value);total+=value.byteLength;
   progress.textContent=`⟳ Downloading… ${bytes?Math.min(100,Math.round(total/bytes*100))+'%':(total/1048576).toFixed(1)+' MB'}`;
 }
 const blob=new Blob(chunks,{type:response.headers.get('content-type')||'application/octet-stream'});
 const obj=URL.createObjectURL(blob);const dl=document.createElement('a');dl.href=obj;dl.download=decodeURIComponent(new URL(url).pathname.split('/').pop());document.body.appendChild(dl);dl.click();dl.remove();setTimeout(()=>URL.revokeObjectURL(obj),60000);
 progress.textContent='✓ File handed to your browser. Check Downloads.';
 }catch(err){progress.textContent='⚠ Download failed: '+err.message;notice(err.message)}
 finally{a.classList.remove('downloading')}
}
async function refreshLibrary(){const a=await request('/api/projects');$('projectsList').innerHTML=a.length?a.map(p=>`<div class="projectRow"><div><b>${p.name}</b><small>${p.id} · ${Math.round(p.duration)} seconds · ${p.outputs?'outputs ready':'not rendered'}</small></div><button class="secondary" data-id="${p.id}">Open →</button></div>`).join(''):'No projects yet';document.querySelectorAll('.projectRow button').forEach(x=>x.onclick=async()=>{await openProject(x.dataset.id);tab('studio')})}
const fields=['template','fps','quality','music','music_volume','voice_volume','lower_music_voiceover','summary_hold','hook_duration','navigation_speed','action_speed','brand','website','instagram','phone','tagline','audio_reference'];
async function refreshSettings(){const s=await request('/api/settings');fields.forEach(k=>{if($(k)){if($(k).type==='checkbox')$(k).checked=!!s[k];else $(k).value=s[k]??''}});$('volumeValue').textContent=Math.round(Number(s.music_volume)*100)+'%';$('voiceDefaultValue').textContent=Math.round(Number(s.voice_volume??1.15)*100)+'%'}
$('music_volume').oninput=()=>$('volumeValue').textContent=Math.round(Number($('music_volume').value)*100)+'%';
$('voice_volume').oninput=()=>$('voiceDefaultValue').textContent=Math.round(Number($('voice_volume').value)*100)+'%';
$('saveSettings').onclick=async()=>{const s={};fields.forEach(k=>{if($(k))s[k]=k==='lower_music_voiceover'?$(k).checked:['fps','summary_hold','hook_duration','navigation_speed','action_speed','music_volume','voice_volume'].includes(k)?Number($(k).value):$(k).value});try{await request('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(s)});$('settingsMsg').textContent='Saved ✓';notice('Settings saved across sessions')}catch(e){notice(e.message)}};
request('/api/health').then(s=>{$('connState').textContent='● Studio '+(s.version||'ready')+(s.ai_connected?' · AI available':' · AI optional')}).catch(()=>{$('connState').textContent='● Offline'});
// Restore the last project on launch so Mixer buttons never silently target a null project.
// If no video exists, the persistent Audio Workspace handles every Mixer action.
(async function restoreAudioContext(){
 updateAudioScope(null);
 try{
  const projects=await request('/api/projects');
  if(!current && projects.length){
   await openProject(projects[0].id);
   $('audioStatus').textContent='✓ Restored your latest project. Music Test, Mix and Remove are ready.';
  }else if(!current){
   const draft=await request('/api/audio-workspace');
   projectVoiceReady=!!draft.has_voice;projectMusicReady=!!draft.has_music;
   const a=draft.audio||{};
   $('project_audio_url').value=a.music_url||'';
   $('project_music_volume').value=a.music_volume??.09;
   $('project_voice_volume').value=a.voice_volume??1.15;
   $('project_music_speed').value=a.music_speed??1;
   $('project_lower_music').checked=a.lower_music_voiceover!==false;
   $('project_audio_rights').checked=!!a.music_url;
   updateAudioNumbers();updateLinkHelp();
  }
 }catch(e){$('audioStatus').textContent='⚠ Could not restore audio context: '+e.message;}
})();


// Update checks are strictly manual. The panel opens only when Check Updates is clicked.
