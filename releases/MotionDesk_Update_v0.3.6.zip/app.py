"""MotionDesk v0.3.6: a local-first persistent video production app.
No paid service is contacted unless the owner opts in for a particular analysis.
"""
from __future__ import annotations
import base64
import io
import ipaddress
import socket
import json
import os
import re
import secrets
import shutil
import subprocess
import threading
import time
import uuid
import wave
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import cv2
import numpy as np
import requests
from fastapi import FastAPI, File, Form, HTTPException, UploadFile, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('MOTIONDESK_DATA_DIR', os.environ.get('SPEEDYPRO_DATA_DIR',str(ROOT / 'data')))).resolve()
DATA.mkdir(parents=True, exist_ok=True)
PREFS = DATA / 'settings.json'
JOBS: dict[str, dict[str, Any]] = {}
IMPORT_JOBS: dict[str, dict[str, Any]] = {}
RESCAN_JOBS: dict[str, dict[str, Any]] = {}
VIDEO_SUFFIXES = {'.mp4','.mov','.mkv','.webm'}
AUDIO_SUFFIXES = {'.mp3','.wav','.m4a','.aac','.ogg'}
FEATURES = ['Excel Import','Front Upload','Back Upload','Sleeve Upload','Front Number','Back Name','Back Number','Name Font','Number Font','Colour Gradient','Outline / Border','Name Curve','Sleeve Export','Print Files']
ROLES = ['raw_excel','raw_front','raw_back','raw_sleeve','final_front','final_back','final_sleeve']
DEFAULT = {
    'brand':'SpeedyPro', 'website':'speedypro.in','instagram':'@speedypro.in',
    'phone':'+91 9073503003','tagline':'DATA IN, DESIGN OUT.',
    'template':'auto','fps':30,'quality':'1080p','music':'sports','music_volume':0.09,
    'voice_volume':1.15,'lower_music_voiceover':True,
    'summary_hold':2.5,'hook_duration':6.0,'navigation_speed':1.5,'action_speed':1.0,
    'audio_reference':'','template_counter':0,
}
app = FastAPI(title='MotionDesk', version='0.3.6')
app.mount('/static', StaticFiles(directory=str(ROOT/'static')), name='static')


def ffprobe(video: Path) -> dict:
    try:
        p = subprocess.run(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_type,width,height,r_frame_rate','-of','json',str(video)], capture_output=True,text=True,check=True)
        j=json.loads(p.stdout); v=next((s for s in j['streams'] if s['codec_type']=='video'),{})
        return {'duration':float(j['format']['duration']),'width':v.get('width',0),'height':v.get('height',0),'fps':v.get('r_frame_rate','0/0')}
    except Exception as e: raise ValueError(f'Video cannot be probed: {e}')


def ff(args: list[str], timeout=1200):
    p=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*args],capture_output=True,text=True,timeout=timeout)
    if p.returncode: raise RuntimeError((p.stderr or 'ffmpeg failed')[-2500:])


def settings() -> dict:
    try: return {**DEFAULT,**json.loads(PREFS.read_text(encoding='utf8'))}
    except Exception: return DEFAULT.copy()


# External audio: import only an HTTPS URL that is itself a publicly reachable
# audio file. Social post pages are not supported and never scraped or ripped.
MUSIC_MAX_BYTES = 40 * 1024 * 1024
SOCIAL_AUDIO_HOSTS = ('youtube.com', 'youtu.be', 'instagram.com', 'facebook.com', 'tiktok.com', 'music.youtube.com')


def audio_file_valid(path: Path) -> bool:
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'stream=codec_type',
                             '-of', 'json', str(path)], capture_output=True, text=True, timeout=25)
    if result.returncode: return False
    try: return any(st.get('codec_type') == 'audio' for st in json.loads(result.stdout).get('streams', []))
    except Exception: return False


def import_direct_audio(url: str, destination: Path) -> str:
    url = url.strip()
    parsed = urlparse(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ValueError('Use a direct HTTPS link to an audio file you have permission to use.')
    hostname = parsed.hostname.lower().rstrip('.')
    if any(hostname == x or hostname.endswith('.'+x) for x in SOCIAL_AUDIO_HOSTS):
        raise ValueError('Social post links are not audio files. Upload a licensed audio file, or paste a direct HTTPS MP3/WAV/M4A link.')
    try:
        ips = {record[4][0] for record in socket.getaddrinfo(hostname, 443, type=socket.SOCK_STREAM)}
        if not ips or not all(ipaddress.ip_address(ip).is_global for ip in ips):
            raise ValueError('Local/internal audio URLs are blocked for safety.')
    except socket.gaierror:
        raise ValueError('Could not find the audio file server.')
    session = requests.Session()
    session.trust_env = False
    part = destination.with_name(destination.name+'.part')
    try:
        with session.get(url, stream=True, allow_redirects=False, timeout=(8,20),
                         headers={'Accept':'audio/*,application/octet-stream'}) as response:
            if 300 <= response.status_code < 400:
                raise ValueError('Redirecting audio links are not supported. Paste the direct audio-file URL.')
            response.raise_for_status()
            kind = response.headers.get('content-type','').lower().split(';',1)[0]
            audio_suffix = Path(parsed.path).suffix.lower()
            if not (kind.startswith('audio/') or (kind in ('application/octet-stream','binary/octet-stream') and audio_suffix in AUDIO_SUFFIXES)):
                raise ValueError('This URL does not return an audio file. Use an authorized direct MP3/WAV/M4A link.')
            claimed = int(response.headers.get('content-length','0') or 0)
            if claimed > MUSIC_MAX_BYTES:raise ValueError('Audio is too large (maximum 40 MB).')
            total = 0
            with part.open('wb') as target:
                for block in response.iter_content(chunk_size=131072):
                    if not block:continue
                    total += len(block)
                    if total > MUSIC_MAX_BYTES:raise ValueError('Audio is too large (maximum 40 MB).')
                    target.write(block)
        if total < 100 or not audio_file_valid(part):
            raise ValueError('The link did not contain a playable audio stream.')
        part.replace(destination)
        return destination.name
    finally:
        if part.exists():part.unlink()
        session.close()


def audio_configuration(p:dict,s:dict) -> dict:
    a=p.get('audio',{})
    return {'music_volume':float(a.get('music_volume',s.get('music_volume',.09))),
            'voice_volume':float(a.get('voice_volume',s.get('voice_volume',1.15))),
            'lower_music_voiceover':bool(a.get('lower_music_voiceover',s.get('lower_music_voiceover',True))),
            'music_url':a.get('music_url',''), 'has_music':bool(p.get('music_file') or p.get('linked_music_file')),
            'has_voice':bool(p.get('voice_file'))}


def save_settings(values:dict):
    clean={k:values[k] for k in DEFAULT if k in values}
    merged={**settings(),**clean}; PREFS.write_text(json.dumps(merged,indent=2),encoding='utf8')
    return merged


def proj(pid):
    if not re.fullmatch(r'[0-9a-f]{12}',pid): raise HTTPException(400,'Invalid project ID')
    base=DATA/pid
    if not (base/'project.json').exists(): raise HTTPException(404,'Project not found')
    return base


def load_project(pid):
    path=proj(pid)/'project.json'
    project=json.loads(path.read_text(encoding='utf8'))
    # Migrate old, *unreviewed* role guesses. Preserve anything owner-reviewed.
    if project.get('evidence')=='heuristic / unverified':
        project['selected']={role:None for role in ROLES}
        project['evidence']='legacy guesses cleared; candidates shown only for review'
        path.write_text(json.dumps(project,indent=2),encoding='utf8')
    if project.get('suggestions_version')!=1 and project.get('frames'):
        # Upgrade saved recordings in place; no re-upload needed.
        project['output_suggestions']=suggested_output_frames(
            project['frames'], path.parent, float(project['meta']['duration']))
        project['suggestions_version']=1
        path.write_text(json.dumps(project,indent=2),encoding='utf8')
    return project

def save_project(pid, p): (proj(pid)/'project.json').write_text(json.dumps(p,indent=2),encoding='utf8')


def font(size=40,bold=True):
    candidates=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf','C:/Windows/Fonts/arialbd.ttf'] if bold else ['/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','C:/Windows/Fonts/arial.ttf']
    for f in candidates:
        if Path(f).exists(): return ImageFont.truetype(f,size)
    return ImageFont.load_default()


def extract_candidates(video:Path, directory:Path, meta:dict, progress=None):
    """Candidate gallery with dense start sampling. Every image is real uploaded footage.

    Timestamps do NOT identify semantic roles. The picker also supports exact frame capture.
    """
    cdir=directory/'frames'; cdir.mkdir(exist_ok=True)
    cap=cv2.VideoCapture(str(video))
    if not cap.isOpened(): raise ValueError('Could not read uploaded video')
    dur=float(meta['duration'])
    # Dense sampling of the opening, where original Excel/front/back screens often flash.
    # Sparse sampling elsewhere keeps large raw videos reasonably inexpensive.
    ranges=((0,min(15,dur),.25),(15,min(35,dur),.65),
            (35,max(35,dur-15),1.8),(max(35,dur-15),dur,.6))
    times=set()
    for lo,hi,step in ranges:
        if hi<=lo: continue
        for t in np.arange(lo,hi,step):
            if .02 <= t <= dur-.05: times.add(round(float(t),3))
    times.update(round(float(t),3) for t in (0.05,.10,.15, min(dur-.1,.4)) if .01<t<dur-.05)
    ts=sorted(times)
    frames=[]
    for i,t in enumerate(ts):
        if progress and (i%8==0 or i==len(ts)-1):progress(i/max(len(ts),1))
        cap.set(cv2.CAP_PROP_POS_MSEC,t*1000)
        ok,frame=cap.read()
        if not ok: continue
        h,w=frame.shape[:2];scale=min(1.0,960/w)
        out=cv2.resize(frame,(int(w*scale),int(h*scale)),interpolation=cv2.INTER_AREA)
        grey=cv2.cvtColor(out,cv2.COLOR_BGR2GRAY)
        sharpness=float(cv2.Laplacian(grey,cv2.CV_64F).var())
        hsv=cv2.cvtColor(out,cv2.COLOR_BGR2HSV)
        roi=hsv[int(hsv.shape[0]*.22):int(hsv.shape[0]*.92),int(hsv.shape[1]*.10):int(hsv.shape[1]*.92)]
        colour_fraction=float(((roi[:,:,1]>80)&(roi[:,:,2]>70)).mean()) if roi.size else 0.0
        name=f'frame_{i:04d}.jpg'
        cv2.imwrite(str(cdir/name),out,[cv2.IMWRITE_JPEG_QUALITY,88])
        frames.append({'id':i,'time':round(t,3),'filename':name,'sharpness':round(sharpness,1),
                       'colour_fraction':round(colour_fraction,4),'url':f'/api/file/{directory.name}/frames/{name}'})
    cap.release()
    if progress:progress(1.0)
    return frames



def suggested_output_frames(frames: list[dict], base: Path, duration: float) -> list[dict]:
    """Free, explainable visual shortlist of POSSIBLE exported file screens.

    It looks for repeated coloured artwork thumbnails on a light background late
    in a recording, not for a fixed 'front' or 'back' timestamp. It does NOT
    semantically verify which garment face is shown. Suggestions never become
    selected/approved source frames without a deliberate user click.
    """
    candidates = []
    for f in frames:
        if f.get('manual') or float(f['time']) < duration * .75:
            continue
        img = cv2.imread(str(base / 'frames' / f['filename']))
        if img is None:
            continue
        h, w = img.shape[:2]
        if h < 100 or w < 150:
            continue
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        roi = hsv[int(h*.22):int(h*.92), int(w*.15):int(w*.90)]
        if not roi.size:
            continue
        saturation = roi[:, :, 1]
        brightness = roi[:, :, 2]
        pale_bg = float(np.mean((saturation < 38) & (brightness > 210)))
        colour_mask = ((saturation > 65) & (brightness > 70)).astype(np.uint8)
        # Exported thumbnails tend to repeat coloured designs across a grid.
        active_cells = 0
        for rr in np.array_split(colour_mask, 4, axis=0):
            for cell in np.array_split(rr, 6, axis=1):
                if cell.size and float(cell.mean()) > .029:
                    active_cells += 1
        score = active_cells + 3 * pale_bg
        # This is strictly a visual cue, NOT identification of front/back.
        if active_cells >= 9 and pale_bg >= .47:
            candidates.append((score, float(f['time']), f))
    candidates.sort(key=lambda x: (-x[0], -x[1]))
    short = []
    for score, t, f in candidates:
        # Avoid ten identical consecutive screenshots. Keep separated scenes.
        if all(abs(t - other['time']) >= 4.5 for other in short):
            short.append({'id':f['id'], 'time':f['time'], 'url':f['url'],
                          'hint':'Possible final/exported-files screenshot', 'verified':False})
        if len(short) >= 4:
            break
    return sorted(short, key=lambda x:x['time'])

def choose_defaults(frames:list[dict], duration:float):
    """No more timestamp=role guesses. Mislabelled artworks are worse than blank picks.

    Fast timeline sampling is free. True semantic identification needs visible evidence,
    optional owner-approved vision analysis or review in the exact-time picker.
    """
    return {role:None for role in ROLES}


def image_at(p:dict, base:Path, role):
    idx=p.get('selected',{}).get(role)
    match=next((f for f in p['frames'] if f['id']==idx),None)
    if not match:return None
    path=base/'frames'/match['filename']
    return Image.open(path).convert('RGB') if path.exists() else None


def contain(img, size):
    return ImageOps.contain(img,size,Image.Resampling.LANCZOS)


def draw_summary(base:Path,p:dict,s:dict,style:str):
    # All output images come from the uploaded video; no source art is invented.
    palettes={
      'sports':('#071427','#ff721a','#f4f8ff','#0d2b4b'),
      'corporate':('#f2f5f9','#1e5d98','#0e243c','#dce7f2'),
      'tech':('#071725','#2dd4d9','#e9fcff','#123e56'),
      'minimal':('#fcfcfc','#eb6421','#101c29','#f0f0f0')}
    bg,accent,ink,card=palettes[style]
    W,H=1920,1080; img=Image.new('RGB',(W,H),bg); d=ImageDraw.Draw(img)
    light=style in ('corporate','minimal'); white='#0a2037' if light else '#ffffff'
    d.rounded_rectangle((46,28,1874,100),16,fill=card)
    logo_path=ROOT/'static'/'brand_logo.png'
    if logo_path.exists():
        logo=contain(Image.open(logo_path).convert('RGB'),(215,66))
        img.paste(logo,(68,32))
    else:d.text((68,46),s['brand'].upper(),font=font(38),fill=white)
    d.text((1370,52),'RAW DATA  →  SPEEDYPRO WORK',font=font(24),fill=accent)
    d.text((72,120),'ONE ORDER. SMARTER JERSEY PRODUCTION.',font=font(53),fill=white)
    sections=[('RAW DATA',['raw_excel','raw_front','raw_back','raw_sleeve'],(56,224,942,846)),
              ('SPEEDYPRO WORK',['final_front','final_back','final_sleeve'],(980,224,1864,846))]
    for label,roles,rect in sections:
        x1,y1,x2,y2=rect
        d.rounded_rectangle(rect,23,fill=card,outline=accent,width=3)
        d.rounded_rectangle((x1+10,y1+10,x2-10,y1+76),12,fill=bg)
        d.text((x1+28,y1+18),label,font=font(37),fill=white)
        available=[(k,image_at(p,base,k)) for k in roles]
        available=[(k,v) for k,v in available if v is not None]
        if not available:
            d.text((x1+65,y1+180),'No verified frame selected',font=font(26),fill=white)
            continue
        n=len(available);cols=2 if n>1 else 1;rows=(n+cols-1)//cols
        w=int((x2-x1-80-(cols-1)*18)/cols); h=int((y2-y1-158-(rows-1)*12)/rows)
        for j,(k,source) in enumerate(available):
            col=j%cols;row=j//cols; xx=x1+35+col*(w+18);yy=y1+96+row*(h+12)
            d.rounded_rectangle((xx,yy,xx+w,yy+h),12,fill='#ffffff')
            photo=contain(source,(w-16,h-43));img.paste(photo,(xx+(w-photo.width)//2, yy+5+(h-40-photo.height)//2))
            tag=k.replace('raw_','').replace('final_','').upper()
            d.text((xx+14,yy+h-34),tag,font=font(21),fill='#10243a')
    # Dynamic features: verified by human or opted-in AI. No DPI advertising.
    features=p.get('features',[])[:7]
    d.rounded_rectangle((64,872,1855,976),23,fill=card)
    icons={'Excel Import':'X','Front Upload':'F','Back Upload':'B','Sleeve Upload':'S','Front Number':'#',
           'Back Name':'N','Back Number':'#','Name Font':'Aa','Number Font':'Aa',
           'Colour Gradient':'G','Outline / Border':'O','Name Curve':'C','Sleeve Export':'S','Print Files':'P'}
    if features:
        x=94
        for tag in features:
            width=max(175,int(d.textlength(tag,font=font(23))+98))
            if x+width>1800:break
            d.rounded_rectangle((x,895,x+width,952),13,outline=accent,width=2)
            d.ellipse((x+11,906,x+46,941),fill=accent)
            sym=icons.get(tag,'✓');symfont=font(19)
            box=d.textbbox((0,0),sym,font=symfont)
            d.text((x+28-(box[2]-box[0])/2,916-(box[3]-box[1])/2),sym,font=symfont,fill=bg)
            d.text((x+56,910),tag,font=font(23),fill=white)
            x+=width+12
    else:
        d.text((105,910),'Real footage • Verified features only',font=font(27),fill=white)
    d.text((70,1007),s['tagline']+'   •   '+s['website'],font=font(31),fill=white)
    return img


def vertical_cover(landscape:Image.Image, s:dict):
    out=Image.new('RGB',(1080,1920),'#071427');d=ImageDraw.Draw(out)
    d.rounded_rectangle((54,115,1026,320),32,fill='#102b4b')
    d.text((88,155),'SPEEDYPRO',font=font(72),fill='white')
    d.text((88,245),'BEFORE / AFTER',font=font(48),fill='#ff721a')
    fitted=contain(landscape,(1080,950));out.paste(fitted,((1080-fitted.width)//2,510))
    d.text((140,1530),'ROTATE PHONE TO WATCH',font=font(48),fill='#ff721a')
    d.text((140,1600),'Full-screen desktop demo',font=font(30),fill='white')
    d.text((140,1692),s['website'],font=font(37),fill='white')
    return out


def end_banner(s:dict,style:str):
    W,H=1920,1080
    bg='#061326';im=Image.new('RGB',(W,H),bg);d=ImageDraw.Draw(im)
    d.polygon([(0,0),(185,0),(0,180)],fill='#fc7224');d.polygon([(1920,1080),(1730,1080),(1920,895)],fill='#fc7224')
    d.rounded_rectangle((120,120,1800,950),30,fill='#10253f',outline='#39a6d2',width=4)
    logo_path=ROOT/'static'/'brand_logo.png'
    if logo_path.exists():
        logo=contain(Image.open(logo_path).convert('RGB'),(310,102))
        im.paste(logo,(200,165))
    else:d.text((205,205),s['brand'],font=font(72),fill='white')
    d.text((200,390),'FOLLOW US FOR',font=font(79),fill='white')
    d.text((200,505),'NEW FEATURES & UPDATES',font=font(63),fill='#ff7529')
    d.line((200,630,1700,630),fill='#72b1d1',width=3)
    for x,label,val in [(200,'INSTAGRAM',s['instagram']),(770,'WHATSAPP / CALL',s['phone']),(1360,'WEBSITE',s['website'])]:
        d.text((x,694),label,font=font(27),fill='#9ec7e3')
        d.text((x,748),val,font=font(31),fill='white')
    d.text((205,885),s['tagline'],font=font(29),fill='#d4e0f0')
    return im


def rotate_intro(output:Path):
    # This is an upright (not sideways) 9:16 instruction.
    im=Image.new('RGB',(1080,1920),'#071427');d=ImageDraw.Draw(im)
    d.text((98,340),'ON MOBILE?',font=font(78),fill='#ffffff')
    d.text((98,440),'ROTATE YOUR PHONE',font=font(60),fill='#ff7629')
    d.rounded_rectangle((395,700,685,1200),50,outline='#ffa657',width=25)
    d.arc((230,820,850,1390),10,160,fill='#ffffff',width=17)
    d.text((225,1540),'FOR THE BEST VIEW',font=font(48),fill='white')
    im.save(output)


def original_music(out:Path, duration:float=30.0,mode='sports'):
    sr=24000;t=np.arange(int(sr*duration),dtype=np.float64)/sr
    if mode=='flute':
        f=440+3*np.sin(2*np.pi*5*t)
        phase=np.cumsum(2*np.pi*f/sr)
        wavef=np.sin(phase)+.19*np.sin(2*phase)+.09*np.sin(3*phase)
        envelope=.5+.2*np.cos(2*np.pi*.5*t)
        samples=.085*wavef*envelope
    else:
        # Original sparse rhythmic synth bed, no copyrighted recordings.
        samples=np.zeros_like(t)
        for b in np.arange(0,duration,.5):
            idx=int(b*sr); length=min(len(samples)-idx,int(sr*.17))
            if length<=0:continue
            ts=np.arange(length)/sr
            tone=(np.sin(2*np.pi*(105-50*ts)*ts)*np.exp(-25*ts)+.2*np.sin(2*np.pi*320*ts)*np.exp(-35*ts))
            samples[idx:idx+length]+=tone*.095
        samples +=.013*np.sin(2*np.pi*165*t)+.007*np.sin(2*np.pi*247*t)
    samples=np.clip(samples,-.8,.8)
    with wave.open(str(out),'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(sr)
        wav.writeframes((samples*32767).astype('<i2').tobytes())


def image_clip(path:Path,out:Path,width:int,height:int,fps:int,duration:float):
    ff(['-loop','1','-framerate',str(fps),'-i',str(path),'-t',f'{duration:.3f}',
        '-vf',f'scale={width}:{height}:force_original_aspect_ratio=decrease,pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:black',
        '-r',str(fps),'-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p',str(out)])


def title_overlay_frames(label: str, target: Path, width: int, height: int, fps: int, duration: float = 2.6):
    """Animate captions with Pillow, not FFmpeg drawtext/Fontconfig.

    FFmpeg's Windows Gyan builds sometimes fail Fontconfig lookup, even when
    Pillow can load local fonts. Render alpha PNG frames as video *inputs*;
    no untrusted font names or Windows drive-colons enter the filter graph.
    """
    from math import ceil
    target.mkdir(parents=True, exist_ok=True)
    for stale in target.glob("title_*.png"):
        stale.unlink()
    scale = min(1.0, 1280 / max(1, width))
    canvas_w = min(1280, width)
    canvas_h = max(1, round(height * canvas_w / width))
    def font_at(sz):
        candidates = [
            'C:/Windows/Fonts/arialbd.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        ]
        for path in candidates:
            if Path(path).exists():
                try: return ImageFont.truetype(path, sz)
                except OSError: pass
        return ImageFont.load_default()
    max_big = min(72, max(36, canvas_w // 17))
    test = ImageDraw.Draw(Image.new('RGBA', (2,2)))
    while max_big > 24 and test.textbbox((0,0), label, font=font_at(max_big))[2] > canvas_w - 90:
        max_big -= 2
    final_font_size = min(32, max(22, max_big//2))
    for i in range(max(1,ceil(duration*fps))):
        t=i/fps
        if t < .78: frac=0.0
        elif t >= 1.32: frac=1.0
        else:
            x=(t-.78)/.54; frac=x*x*(3-2*x)
        size=max(20,round(max_big*(1-frac)+final_font_size*frac))
        frame=Image.new('RGBA',(canvas_w,canvas_h),(0,0,0,0))
        draw=ImageDraw.Draw(frame)
        ft=font_at(size)
        box=draw.textbbox((0,0),label,font=ft)
        tw,th=box[2]-box[0],box[3]-box[1]
        cx=canvas_w/2
        cy=canvas_h*.48*(1-frac)+canvas_h*.91*frac
        pad_x=max(18,round(size*.38));pad_y=max(12,round(size*.35))
        left=round(cx-tw/2-pad_x);right=round(cx+tw/2+pad_x)
        top=round(cy-th/2-pad_y);bottom=round(cy+th/2+pad_y)
        alpha=1.0 if t<2.35 else max(0.0,(duration-t)/max(.05,duration-2.35))
        draw.rounded_rectangle((left,top,right,bottom),radius=max(12,round(size*.3)),fill=(6,22,42,round(225*alpha)),outline=(255,111,24,round(205*alpha)),width=max(2,round(size*.045)))
        draw.text((cx-tw/2,cy-th/2-box[1]),label,font=ft,fill=(255,255,255,round(255*alpha)))
        frame.save(target/f'title_{i:04d}.png',optimize=True)
    return target/'title_%04d.png'


def movie_clip(source:Path,out:Path,start:float,length:float,width:int,height:int,fps:int,speed:float,label:str='',rotate=False):
    # Place text onto the *landscape* video before its 90-degree rotation.
    source_meta=ffprobe(source); is_vert=source_meta['height']>source_meta['width']
    ow,oh=(height,width) if rotate else (width,height)
    filters=[]
    if is_vert: filters+=['transpose=2']
    filters += [f'scale={ow}:{oh}:force_original_aspect_ratio=decrease',f'pad={ow}:{oh}:(ow-iw)/2:(oh-ih)/2:black']
    filters += [f'setpts=(PTS-STARTPTS)/{speed:.5f}']
    opts=['-ss',f'{start:.3f}','-t',f'{length:.3f}','-i',str(source)]
    inputlabel='[0:v]'
    graph=[]
    base='[base]';graph.append(inputlabel+','.join(filters)+base)
    if label:
        frame_pattern=title_overlay_frames(label,out.parent/f'_titles_{out.stem}',ow,oh,fps)
        opts += ['-framerate',str(fps),'-start_number','0','-i',str(frame_pattern)]
        graph.append('[1:v]scale='+str(ow)+':'+str(oh)+',format=rgba[caption]')
        graph.append('[base][caption]overlay=x=0:y=0:shortest=0:repeatlast=0:eof_action=pass:format=auto[composed]')
        base='[composed]'
    if rotate:
        graph.append(base+'transpose=1[out]')
    else:
        graph.append(base+'format=yuv420p[out]')
    ff([*opts,'-filter_complex',';'.join(graph),'-map','[out]','-an',
        '-r',str(fps),'-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p',str(out)])


def select_style(s:dict):
    arr=['sports','corporate','tech','minimal']
    return s['template'] if s['template'] in arr else arr[int(s.get('template_counter',0))%4]


def report_progress(pid:str,percent:int,step:str):
    job=JOBS.get(pid)
    if job and job.get('status')=='running':
        job['progress']=max(0,min(100,int(percent)))
        job['message']=step


def produce(pid:str):
    p=load_project(pid);base=proj(pid);s=settings();meta=p['meta'];source=base/p['source'];
    audio=audio_configuration(p,s)
    style=select_style(s);w,h=(1920,1080) if s['quality']=='1080p' else (3840,2160)
    fps=int(s.get('fps',30)); folder=base/'exports';folder.mkdir(exist_ok=True)
    report_progress(pid,2,'Preparing authentic artwork comparison')
    # summary and end screens, scaled by ffmpeg if 4K requested
    summary=draw_summary(base,p,s,style); summary.save(folder/'Cover_16x9.png')
    vertical_cover(summary,s).save(folder/'Cover_9x16.png')
    end_banner(s,style).save(folder/'End_Card.png')
    rotate_intro(folder/'Rotate_Intro.png')
    frame_times={role:next((f['time'] for f in p['frames'] if f['id']==idx),None) for role,idx in p.get('selected',{}).items()}
    d=meta['duration']
    # Use actual motion segments, rather than screenshot slides, for hook and tutorial.
    motion_times=sorted(set([max(0, min(float(t or 0),d-2)) for t in [frame_times.get('raw_excel'),frame_times.get('raw_front'),frame_times.get('raw_back'),frame_times.get('final_back'),frame_times.get('final_front')] if t is not None]))
    if len(motion_times)<3:motion_times=[d*.06,d*.18,d*.5,d*.8,d*.94]
    phases=[('Upload Player Data',d*.12),('Upload Designs',d*.28),('Customize Name & Number',d*.52),('Preview Changes',d*.67),('Export Print Files',d*.80),('Final Result',d*.94)]
    # Default heuristics are deliberately generic. Specific feature badges are only user/AI verified.
    scenes=[(max(.1,t),min(8.5,max(d-t-.1,.2)),label) for label,t in phases if t<d-.5]
    records={}
    for format_index,(format_name,rot) in enumerate([('16x9',False),('9x16',True)]):
        phase_base=5+format_index*45
        report_progress(pid,phase_base,f'Creating {format_name} opening and cover')
        parts=folder/f'parts_{format_name}';parts.mkdir(exist_ok=True)
        target_w,target_h=(h,w) if rot else (w,h)
        files=[]
        if rot:
            intro=parts/'01_rotate.mp4';image_clip(folder/'Rotate_Intro.png',intro,target_w,target_h,fps,1.0);files.append(intro)
        summary_file=parts/'02_summary.mp4'
        if rot:
            rotated=folder/'Summary_Rotated.png';summary.rotate(-90,expand=True).save(rotated)
            image_clip(rotated,summary_file,target_w,target_h,fps,float(s['summary_hold']))
        else:image_clip(folder/'Cover_16x9.png',summary_file,target_w,target_h,fps,float(s['summary_hold']))
        files.append(summary_file)
        # hook: ~6s of moving action shots, with real source audio excluded and original bed under.
        per_clip=min(1.6,max(.8,float(s['hook_duration'])/max(3,len(motion_times))))
        for idx,t in enumerate(motion_times):
            report_progress(pid,phase_base+5+int(8*idx/max(1,len(motion_times))),f'{format_name}: moving hook {idx+1}/{len(motion_times)}')
            out=parts/f'10_hook_{idx:02d}.mp4'
            movie_clip(source,out,t,min(per_clip*1.5,max(d-t-.1,.2)),target_w,target_h,fps,1.35,'',rotate=rot)
            files.append(out)
        # main video: one larger part per stage, preserve click/transition near 1x.
        for idx,(tlen,t,lab) in enumerate([(length,start,lab) for start,length,lab in scenes]):
            report_progress(pid,phase_base+14+int(17*idx/max(1,len(scenes))),f'{format_name}: {lab}')
            out=parts/f'30_stage_{idx:02d}.mp4'
            movie_clip(source,out,t,min(tlen,max(d-t-.1,.2)),target_w,target_h,fps,
                       float(s['action_speed'] if idx in (0,2,3,4) else s['navigation_speed']),lab,rotate=rot)
            files.append(out)
        end_src=folder/'End_Card.png'
        if rot:
            rend=folder/'End_Rotated.png';Image.open(end_src).rotate(-90,expand=True).save(rend);end_src=rend
        endfile=parts/'99_end.mp4';image_clip(end_src,endfile,target_w,target_h,fps,5.5);files.append(endfile)
        report_progress(pid,phase_base+32,f'{format_name}: joining scenes and mixing sound')
        concat=parts/'joined.mp4';lst=parts/'concat.txt';lst.write_text('\n'.join("file '"+str(f).replace("'","'\\''")+"'" for f in files),encoding='utf8')
        ff(['-f','concat','-safe','0','-i',str(lst),'-c','copy',str(concat)])
        total=ffprobe(concat)['duration']
        # Music/voice is optional; external social links are references, not auto-downloaded.
        music_file=base/p['linked_music_file'] if p.get('linked_music_file') else (base/p['music_file'] if p.get('music_file') else folder/'Original_Instrumental.wav')
        if not music_file.exists(): original_music(music_file,max(total+1,15),s['music'] if s['music'] in ('sports','flute') else 'sports')
        output=folder/f'SpeedyPro_{format_name}_FINAL.mp4'
        vpath=base/p['voice_file'] if p.get('voice_file') else None
        if vpath and vpath.exists():
            ff(['-i',str(concat),'-stream_loop','-1','-i',str(music_file),'-i',str(vpath),
                '-filter_complex',f'[1:a]volume={max(0.0,min(1.0,audio["music_volume"]*(.3 if audio["lower_music_voiceover"] else 1.0))):.3f},atrim=0:{total:.3f}[m];[2:a]volume={max(0.0,min(2.0,audio["voice_volume"])):.3f},apad,atrim=0:{total:.3f}[v];[m][v]amix=inputs=2:duration=first:normalize=0[a]' ,
                '-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart',str(output)])
        else:
            ff(['-i',str(concat),'-stream_loop','-1','-i',str(music_file),
                '-filter_complex',f'[1:a]volume={float(audio["music_volume"]):.3f},atrim=0:{total:.3f}[a]',
                '-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart',str(output)])
        q=ffprobe(output)
        if q['height']!=target_h or q['width']!=target_w or abs(q['duration']-total)>1:raise RuntimeError('Output QA failed')
        records[format_name]={'url':f'/api/file/{pid}/exports/{output.name}','duration':round(q['duration'],2),'width':target_w,'height':target_h}
        # Also create a concise Before→After slow-motion teaser from genuine moving footage.
        raw_t=frame_times.get('raw_front') or frame_times.get('raw_back') or frame_times.get('raw_excel') or (d*.08)
        final_t=frame_times.get('final_back') or frame_times.get('final_front') or (d*.91)
        report_progress(pid,phase_base+38,f'{format_name}: preparing Before/After promo')
        teaser_parts=[summary_file]
        for ii,(tt,label,sp) in enumerate([(raw_t,'RAW DESIGN',.95),(final_t,'SPEEDYPRO RESULT',.80)]):
            mo=parts/f'80_teaser_{ii}.mp4'
            movie_clip(source,mo,max(0,min(tt,d-3)),min(2.6,max(d-tt-.1,.3)),target_w,target_h,fps,sp,label,rotate=rot)
            teaser_parts.append(mo)
        teaser_parts.append(endfile)
        teaser_list=parts/'teaser_list.txt';teaser_list.write_text('\n'.join("file '"+str(f)+"'" for f in teaser_parts),encoding='utf8')
        teaser_join=parts/'teaser_join.mp4';ff(['-f','concat','-safe','0','-i',str(teaser_list),'-c','copy',str(teaser_join)])
        teaser_duration=ffprobe(teaser_join)['duration']
        teaser_dest=folder/f'SpeedyPro_{format_name}_BEFORE_AFTER.mp4'
        ff(['-i',str(teaser_join),'-stream_loop','-1','-i',str(music_file),
            '-filter_complex',f'[1:a]volume={float(audio["music_volume"]):.3f},atrim=0:{teaser_duration:.3f}[a]',
            '-map','0:v','-map','[a]','-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart',str(teaser_dest)])
        tq=ffprobe(teaser_dest)
        if tq['height']!=target_h or tq['width']!=target_w:raise RuntimeError('Teaser QA failed')
        records[format_name+'_teaser']={'url':f'/api/file/{pid}/exports/{teaser_dest.name}','duration':round(tq['duration'],2),'width':target_w,'height':target_h}
    report_progress(pid,96,'Checking outputs and preparing downloads')
    (folder/'Production_Report.json').write_text(json.dumps({'source':p['meta'],'style':style,'outputs':records,'selected':p.get('selected',{}),'verified_features':p.get('features',[]),'audio_settings':audio, 'note':'Frame recommendations are heuristic unless confirmed/AI-reviewed. 60fps and 4K may upscale/duplicate source pixels.'},indent=2))
    # Offline SEO pack: grounded generic copy, not a claim of currently trending tags.
    verified=p.get('features',[])
    features_text='\n'.join('• '+f for f in verified) if verified else '• Real order workflow and final print files'
    taglist=['#SpeedyPro','#JerseyAutomation','#JerseyPrinting','#SportswearDesign','#CustomJerseys',
             '#SublimationPrinting','#JerseyDesignSoftware','#Teamwear','#SportswearManufacturing',
             '#JerseyProduction','#PrintingBusiness','#Sportswear','#JerseyNameNumber','#PrintWorkflow','#SmallBusinessTools']
    txt=(f"COMMON PUBLISHING PACK | {p.get('name','SpeedyPro')}\n\n"
         "TITLE\nSpeedyPro | From Raw Player Data to Jersey Print Files\n\n"
         "CAPTION\nSee how a real jersey order moves from its original player details and designs "
         "through SpeedyPro to the final print files.\n\n"+features_text+
         f"\n\nFor jersey printers, apparel designers and sportswear businesses.\n"
         f"Explore SpeedyPro: https://{s['website']}\n"
         f"Follow: {s['instagram']}\n\n"
         "CANDIDATE HASHTAGS (not verified trending)\n"+' '.join(taglist)+
         "\n\nUse a smaller relevant selection when a platform limits hashtag count.\n")
    (folder/'Publishing_Copy.txt').write_text(txt,encoding='utf8')
    p['outputs']=records;save_project(pid,p)
    # update round-robin position only once after successful complete render
    s['template_counter']=int(s.get('template_counter',0))+1;save_settings(s)
    report_progress(pid,100,'Four videos are ready to download')
    return records


@app.middleware('http')
async def auth(request:Request, call_next):
    # Owner can opt into simple access protection before exposing to LAN/mobile.
    password=os.environ.get('MOTIONDESK_APP_PASSWORD', os.environ.get('SPEEDYPRO_APP_PASSWORD',''))
    if password and request.url.path not in ('/static/style.css',):
        header=request.headers.get('authorization','')
        expected='Basic '+base64.b64encode(('studio:'+password).encode()).decode()
        if not secrets.compare_digest(header,expected):
            return HTMLResponse('Authentication required',status_code=401,headers={'WWW-Authenticate':'Basic realm="MotionDesk"'})
    return await call_next(request)


@app.get('/',response_class=HTMLResponse)
def home():return (ROOT/'static'/'index.html').read_text(encoding='utf8')

@app.get('/api/settings')
def get_settings():return settings()

@app.post('/api/settings')
async def post_settings(payload:dict):
    for key in ('fps','quality','template','music'):
        if key not in payload:continue
        if key=='fps' and int(payload[key]) not in (30,60):raise HTTPException(400,'fps must be 30 or 60')
        if key=='quality' and payload[key] not in ('1080p','4K'):raise HTTPException(400,'Invalid quality')
        if key=='template' and payload[key] not in ('auto','sports','corporate','tech','minimal'):raise HTTPException(400,'Invalid template')
        if key=='music' and payload[key] not in ('sports','flute','upload'):raise HTTPException(400,'Invalid music')
    return save_settings(payload)

@app.get('/api/projects')
def list_projects():
    res=[]
    for f in DATA.glob('*/project.json'):
        try:
            p=json.loads(f.read_text());res.append({'id':p['id'],'name':p['name'],'created':p['created'],'duration':p['meta']['duration'],'outputs':bool(p.get('outputs'))})
        except:continue
    return sorted(res,key=lambda x:x['created'],reverse=True)

@app.post('/api/upload')
async def upload(video:UploadFile=File(...),name:str=Form('New SpeedyPro Episode'),voice:UploadFile|None=File(None),music:UploadFile|None=File(None)):
    """Return after the upload reaches this laptop; frame scanning runs in a worker.

    This lets the browser distinguish transfer, scanning and human review instead
    of appearing frozen while OpenCV decodes hundreds of frames.
    """
    ext=Path(video.filename or '').suffix.lower()
    if ext not in VIDEO_SUFFIXES:raise HTTPException(400,'Upload an MP4/MOV/MKV/WEBM video')
    pid=uuid.uuid4().hex[:12];base=DATA/pid;base.mkdir()
    source=base/('source'+ext)
    try:
        nbytes=0
        with source.open('wb') as dest:
            while chunk:=await video.read(1024*1024):
                nbytes+=len(chunk)
                if nbytes>5*1024*1024*1024:raise ValueError('Video exceeds 5 GB limit')
                dest.write(chunk)
        if nbytes<1000:raise ValueError('The selected video is empty')
        assets={}
        for kind,asset in [('voice',voice),('music',music)]:
            if not asset or not asset.filename:continue
            suffix=Path(asset.filename).suffix.lower()
            if suffix not in AUDIO_SUFFIXES:continue
            filename=f'{kind}{suffix}'
            with (base/filename).open('wb') as f:
                while chunk:=await asset.read(1024*1024):f.write(chunk)
            assets[kind+'_file']=filename
    except Exception as exc:
        shutil.rmtree(base,ignore_errors=True)
        raise HTTPException(400,str(exc))
    IMPORT_JOBS[pid]={'status':'scanning','progress':3,'message':'Video uploaded. Checking file and scanning frames…'}
    def scan():
        try:
            meta=ffprobe(source)
            if meta['duration']<=0:raise ValueError('Video has no usable frames')
            IMPORT_JOBS[pid].update(progress=12,message='Video verified. Finding useful frames…')
            def report(f):
                IMPORT_JOBS[pid].update(progress=12+int(f*84),message=f'Scanning real footage: {int(f*100)}%')
            frames=extract_candidates(source,base,meta,progress=report)
            if not frames:raise ValueError('No video frames could be extracted')
            p={'id':pid,'name':name[:80],'created':time.time(),'source':source.name,'meta':meta,'frames':frames,
               'selected':choose_defaults(frames,meta['duration']),'features':[],
               'output_suggestions':suggested_output_frames(frames,base,meta['duration']),'suggestions_version':1,
               'evidence':'source scan completed; unverified roles need review',
               'outputs':{},'voice_file':assets.get('voice_file'),'music_file':assets.get('music_file')}
            (base/'project.json').write_text(json.dumps(p,indent=2),encoding='utf8')
            IMPORT_JOBS[pid].update(status='completed',progress=100,message=f'{len(frames)} frames scanned. Select actual Raw Data and Final Output views.',frame_count=len(frames))
        except Exception as exc:
            IMPORT_JOBS[pid].update(status='failed',progress=0,message=f'Scan failed: {exc}')
    threading.Thread(target=scan,daemon=True).start()
    return {'id':pid,'status':'scanning','message':'Upload complete. Frame scan started.'}

@app.get('/api/project/{pid}/import-status')
def import_status(pid:str):
    job=IMPORT_JOBS.get(pid)
    if job:return job
    if (DATA/pid/'project.json').exists():return {'status':'completed','progress':100,'message':'Recording already imported'}
    raise HTTPException(404,'Import job not found (it may have been interrupted by a restart)')

@app.get('/api/project/{pid}/source')
def source_video(pid:str):
    p=load_project(pid)
    source=proj(pid)/p['source']
    if not source.exists():raise HTTPException(404,'Original video missing')
    # Starlette FileResponse supports browser video seeking with HTTP Range.
    return FileResponse(str(source), media_type='video/mp4')


@app.post('/api/project/{pid}/rescan')
def rescan(pid:str):
    """Recompute real gallery in the background, preserving any owner-picked roles.

    Earlier builds silently repeated the same gallery and reset selections; the new
    progress endpoint makes it clear this is frame extraction, not AI recognition.
    """
    p=load_project(pid)
    job=RESCAN_JOBS.get(pid)
    if job and job.get('status')=='scanning':
        return {'status':'scanning','message':'A rescan is already running'}
    RESCAN_JOBS[pid]={'status':'scanning','progress':0,'message':'Opening original recording…'}
    def worker():
        try:
            base=proj(pid)
            current=load_project(pid)
            old_frame_by_id={f['id']:f for f in current['frames']}
            def progress(frac):
                pct=min(98,max(1,round(float(frac)*100)))
                RESCAN_JOBS[pid].update(progress=pct,message=f'Looking for short-lived images: {pct}%')
            frames=extract_candidates(base/current['source'],base,current['meta'],progress=progress)
            if not frames:raise ValueError('No candidate frames found')
            # Exact-time captures are stored under manual_* and must survive rescans.
            manual=[dict(f) for f in current['frames'] if f.get('manual') and (base/'frames'/f['filename']).exists()]
            id_map={f['filename']:f['id'] for f in frames}
            nextid=max(f['id'] for f in frames)+1
            for f in manual:
                f['id']=nextid;nextid+=1
                frames.append(f);id_map[f['filename']]=f['id']
            choices={}
            for role in ROLES:
                old=old_frame_by_id.get(current.get('selected',{}).get(role))
                choices[role]=id_map.get(old['filename']) if old else None
            current['frames']=frames
            current['selected']=choices
            current['output_suggestions']=suggested_output_frames(frames,base,float(current['meta']['duration']))
            current['suggestions_version']=1
            current['evidence']='rescan completed; reviewed frames kept; possible export screenshots suggested separately'
            save_project(pid,current)
            RESCAN_JOBS[pid].update(status='completed',progress=100,message=f'{len(frames)} real frames ready; open the gallery to pick source images')
        except Exception as exc:
            RESCAN_JOBS[pid].update(status='failed',message=str(exc)[:500])
    threading.Thread(target=worker,daemon=True).start()
    return {'status':'scanning','message':'Rescan started'}


@app.get('/api/project/{pid}/rescan-status')
def rescan_status(pid:str):
    proj(pid)
    job=RESCAN_JOBS.get(pid)
    return job or {'status':'idle','progress':0,'message':'No rescan started'}


@app.post('/api/project/{pid}/capture-frame')
def capture_frame(pid:str,payload:dict):
    p=load_project(pid);base=proj(pid)
    try:t=float(payload.get('time'))
    except (TypeError,ValueError):raise HTTPException(400,'Enter an exact timestamp in seconds')
    duration=p['meta']['duration']
    if not np.isfinite(t) or t<0 or t>=duration:raise HTTPException(400,'Timestamp out of video range')
    role=payload.get('role')
    if role not in ROLES:raise HTTPException(400,'Choose a valid source role')
    # Decode at the requested timestamp, even if original view lasts only 0.1 sec.
    nextid=max((int(f['id']) for f in p['frames']),default=-1)+1
    name=f'manual_{nextid:05d}.png';target=base/'frames'/name
    try:
        ff(['-ss',f'{t:.3f}','-i',str(base/p['source']),'-frames:v','1',
            '-vf','scale=1440:-2:flags=lanczos','-update','1',str(target)],timeout=120)
        if not target.exists() or target.stat().st_size<500:raise RuntimeError('Empty video frame')
    except Exception as e:
        target.unlink(missing_ok=True)
        raise HTTPException(422,'Could not capture that moment: '+str(e)[:260])
    record={'id':nextid,'time':round(t,3),'filename':name,'sharpness':0,
            'colour_fraction':0,'url':f'/api/file/{pid}/frames/{name}','manual':True}
    p['frames'].append(record)
    p['selected'][role]=nextid
    p['evidence']='exact timestamp selected by owner'
    save_project(pid,p)
    return {'frame':record,'selected':p['selected'],'evidence':p['evidence']}


@app.get('/api/project/{pid}')
def get_project(pid:str):return load_project(pid)

@app.post('/api/project/{pid}/selection')
async def selection(pid:str,payload:dict):
    p=load_project(pid)
    valid={f['id'] for f in p['frames']}
    chosen=payload.get('selected',{})
    for k,v in chosen.items():
        if k not in ROLES or (v is not None and int(v) not in valid):raise HTTPException(400,'Invalid frame selection')
    p['selected']={k:(int(v) if v is not None else None) for k,v in chosen.items()}
    p['features']=[f for f in payload.get('features',[]) if f in FEATURES]
    p['evidence']=payload.get('evidence','owner-reviewed')
    save_project(pid,p)
    return {'selected':p['selected'],'features':p['features']}

@app.post('/api/project/{pid}/ai-analyze')
async def ai_analyze(pid:str,payload:dict):
    if payload.get('acknowledge_billed_api') is not True:
        raise HTTPException(400,'Explicit confirmation required before billed AI analysis')
    key=os.environ.get('OPENAI_API_KEY','')
    if not key:raise HTTPException(503,'OPENAI_API_KEY not configured: no AI call made. Free scene sampling still works.')
    p=load_project(pid); base=proj(pid)
    # Sparse, bounded screenshot samples only, to cap cost and avoid sharing full videos.
    frames=p['frames']; selected=sorted({min(range(len(frames)),key=lambda i:abs(frames[i]['time']-p['meta']['duration']*f)) for f in [0,.01,.03,.09,.18,.3,.48,.67,.80,.9,.98]})
    image_parts=[]
    for i in selected:
        f=frames[i];im=Image.open(base/'frames'/f['filename']);im.thumbnail((640,360))
        buf=io.BytesIO();im.save(buf,format='JPEG',quality=68)
        image_parts.append({'type':'input_text','text':f'Image index={f["id"]}, timestamp={f["time"]}s'})
        image_parts.append({'type':'input_image','image_url':'data:image/jpeg;base64,'+base64.b64encode(buf.getvalue()).decode()})
    instruction=("You are inspecting REAL software screenshots. Return ONLY JSON: {\"roles\":{\"raw_excel\":integer_or_null,\"raw_front\":integer_or_null,\"raw_back\":integer_or_null,\"raw_sleeve\":integer_or_null,\"final_front\":integer_or_null,\"final_back\":integer_or_null,\"final_sleeve\":integer_or_null},\"features\":[strings],\"notes\":string}. "
                 "Only use image indices provided; missing/uncertain=null. Prove FRONT/BACK/SLEEVE by visible evidence. Feature choices: "+', '.join(FEATURES)+". Never guess a change from mere availability of a control. No false claims.")
    r=requests.post('https://api.openai.com/v1/responses',headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},json={'model':os.environ.get('SPEEDYPRO_VISION_MODEL','gpt-4.1-mini'),'input':[{'role':'user','content':[{'type':'input_text','text':instruction},*image_parts]}],'max_output_tokens':650},timeout=75)
    if not r.ok:raise HTTPException(502,f'AI analysis request failed: {r.status_code} '+r.text[:350])
    out=r.json();chunks=[x.get('text','') for item in out.get('output',[]) for x in item.get('content',[]) if x.get('type')=='output_text']
    text=''.join(chunks).strip();text=re.sub(r'^```(?:json)?\s*|\s*```$','',text).strip()
    try:result=json.loads(text)
    except:raise HTTPException(502,'AI returned non-JSON output; no project changes made')
    valid={f['id'] for f in frames}
    roles={k:(int(v) if str(v).isdigit() and int(v) in valid else None) for k,v in result.get('roles',{}).items() if k in ROLES}
    # Apply only evidence-backed suggestions. User can correct before publishing.
    p['selected'].update(roles);p['features']=[f for f in result.get('features',[]) if f in FEATURES]
    p['evidence']='AI suggested (review recommended)';save_project(pid,p)
    return {'selected':p['selected'],'features':p['features'],'notes':result.get('notes',''),'evidence':p['evidence']}

@app.post('/api/project/{pid}/audio')
async def project_audio(pid: str, music_url: str = Form(''),
                        rights_confirmed: bool = Form(False),
                        music_volume: float = Form(.09), voice_volume: float = Form(1.15),
                        lower_music_voiceover: bool = Form(True),
                        music: UploadFile | None = File(None),
                        voice: UploadFile | None = File(None)):
    p=load_project(pid);base=proj(pid)
    if JOBS.get(pid,{}).get('status')=='running':raise HTTPException(409,'Cannot change audio during video rendering')
    if not 0<=music_volume<=1 or not 0<=voice_volume<=2:
        raise HTTPException(400,'Music must be 0–100% and voiceover 0–200%')
    if music_url.strip() and music_url.strip()!=p.get('audio',{}).get('music_url','') and not rights_confirmed:
        raise HTTPException(400,'Confirm you have permission to use the linked audio')
    old_audio=p.get('audio',{})
    imported=None
    if music_url.strip() and music_url.strip()!=old_audio.get('music_url',''):
        try:imported=import_direct_audio(music_url.strip(),base/'music_from_link.bin')
        except Exception as e:raise HTTPException(400,str(e))
    new_files={}
    for kind,asset in [('music',music),('voice',voice)]:
        if asset is None or not asset.filename:continue
        suffix=Path(asset.filename).suffix.lower()
        if suffix not in AUDIO_SUFFIXES:raise HTTPException(400,'Upload MP3, WAV, M4A, AAC or OGG audio')
        dest=base/f'{kind}_studio{suffix}'
        total=0
        with dest.open('wb') as out:
            while block:=await asset.read(131072):
                total+=len(block)
                if total> MUSIC_MAX_BYTES:
                    dest.unlink(missing_ok=True);raise HTTPException(400,'Audio file must be under 40 MB')
                out.write(block)
        if not audio_file_valid(dest):
            dest.unlink(missing_ok=True);raise HTTPException(400,'This file has no playable audio stream')
        new_files[kind+'_file']=dest.name
    if imported:
        p['linked_music_file']=imported
        p.pop('music_file',None)
    if music_url.strip()=='' and old_audio.get('music_url'):
        p.pop('linked_music_file',None)
    if new_files.get('music_file'):
        p.pop('linked_music_file',None)
    p.update(new_files)
    a={'music_url':music_url.strip() if not new_files.get('music_file') else '',
       'music_volume':music_volume,'voice_volume':voice_volume,
       'lower_music_voiceover':lower_music_voiceover}
    p['audio']=a
    # Changes need a fresh render; an old completed output must not be marked approved for new audio.
    p['download_approved']=False
    p['outputs']={}  # Old outputs must not be approved after an audio change.
    save_project(pid,p)
    return {'status':'saved','audio':audio_configuration(p,settings()),'rerender_required':True}


@app.get('/api/project/{pid}/preview/{filename}')
def preview_output(pid: str, filename: str):
    p=load_project(pid)
    if not re.fullmatch(r'[A-Za-z0-9_\-.]+\.mp4',filename,flags=re.IGNORECASE):
        raise HTTPException(400,'Invalid preview filename')
    allowed={record['url'].rsplit('/',1)[-1] for record in p.get('outputs',{}).values()}
    if filename not in allowed:raise HTTPException(404,'This preview is not part of the finished project')
    path=proj(pid)/'exports'/filename
    if not path.is_file():raise HTTPException(404,'Preview file was not created')
    return FileResponse(str(path),media_type='video/mp4',content_disposition_type='inline')


@app.post('/api/project/{pid}/approve')
def approve_outputs(pid: str):
    p=load_project(pid)
    if JOBS.get(pid,{}).get('status')=='running':raise HTTPException(409,'Render not finished')
    records=p.get('outputs',{})
    if len(records)!=4:raise HTTPException(409,'Four videos must be rendered before approval')
    if any(not (proj(pid)/'exports'/rec['url'].rsplit('/',1)[-1]).exists() for rec in records.values()):
        raise HTTPException(409,'A video output is missing; render again')
    p['download_approved']=True
    p['approved_at']=time.time()
    save_project(pid,p)
    return {'approved':True, 'count':len(records)}


@app.post('/api/project/{pid}/render')
def render(pid:str):
    project=load_project(pid)
    picked=project.get('selected',{})
    if not any(picked.get(r) is not None for r in ['raw_excel','raw_front','raw_back','raw_sleeve']):
        raise HTTPException(422,'Choose at least one correct RAW DATA frame before rendering')
    if not any(picked.get(r) is not None for r in ['final_front','final_back','final_sleeve']):
        raise HTTPException(422,'Choose at least one correct FINAL OUTPUT frame before rendering')
    if pid in JOBS and JOBS[pid]['status']=='running':raise HTTPException(409,'Render already in progress')
    project['download_approved']=False;save_project(pid,project)
    JOBS[pid]={'status':'running','message':'Preparing files...','progress':0,'started':time.time()}
    def work():
        try:JOBS[pid].update(status='completed',result=produce(pid),message='Video pair verified and ready')
        except Exception as e:
            message=str(e)
            if 'drawtext' in message.lower() or 'filter' in message.lower():
                message='Video title rendering failed. MotionDesk now uses a cross-platform system font; inspect log if this repeats. '+message[-450:]
            JOBS[pid].update(status='failed',message=message,progress=0)
    threading.Thread(target=work,daemon=True).start()
    return JOBS[pid]

@app.get('/api/project/{pid}/status')
def status(pid:str):return JOBS.get(pid,{'status':'idle'})

@app.get('/api/file/{pid}/{folder}/{filename}')
def get_file(pid:str,folder:str,filename:str):
    if folder not in ('frames','exports') or not re.fullmatch(r'[A-Za-z0-9_\-.]+',filename):raise HTTPException(400,'Bad file path')
    path=proj(pid)/folder/filename
    if not path.exists():raise HTTPException(404,'File not found')
    if folder=='exports' and filename.lower().endswith('.mp4') and not load_project(pid).get('download_approved',False):
        raise HTTPException(403,'Preview and approve your finished video before downloading')
    return FileResponse(str(path),filename=filename if folder=='exports' else None)

# MotionDesk v0.3.6: owner-controlled update channel, disabled until configured.
import motiondesk_updater as updates

@app.get('/api/health')
def health():
    return {'status':'ok','version':'0.3.6','ffmpeg':bool(shutil.which('ffmpeg')),'ai_connected':bool(os.environ.get('OPENAI_API_KEY'))}

@app.get('/api/updates/check')
def check_updates():
    return updates.check()

@app.get('/api/updates/status')
def update_status():
    return updates.state()

@app.post('/api/updates/install')
def install_update(request:Request):
    if any(j.get('status')=='running' for j in JOBS.values()) or any(j.get('status')=='running' for j in IMPORT_JOBS.values()) or any(j.get('status')=='running' for j in RESCAN_JOBS.values()):
        raise HTTPException(409,'A video is still processing. Finish it before installing an update.')
    # Never permit an update operation from a remote browser or embedded cross-site page.
    if request.client.host not in {'127.0.0.1','::1','localhost'}:
        raise HTTPException(403,'Updates must be installed locally on this computer')
    origin=request.headers.get('origin','')
    if origin and origin not in {'http://127.0.0.1:8765','http://localhost:8765'}:
        raise HTTPException(403,'Cross-site update requests are blocked')
    try:return updates.install_async(os.getpid())
    except ValueError as exc:raise HTTPException(409,str(exc))
